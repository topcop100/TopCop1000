# -*- coding: utf-8 -*-
import json
import os
import xbmcvfs

ADDON_DATA = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.topcop1000/")
SETTINGS_FILE = os.path.join(ADDON_DATA, "sources.json")

DEFAULTS = {
    "m3u_source": "",
    "sources": {
        "stalker": [],
        "xtream": [],
        "m3u": [],
        "enigma2": [],
        "plex": [],
        "python": []
    }
}

def _ensure_dir():
    os.makedirs(ADDON_DATA, exist_ok=True)

def load_settings():
    _ensure_dir()
    if not os.path.exists(SETTINGS_FILE):
        save_settings(DEFAULTS)
        return json.loads(json.dumps(DEFAULTS))
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        data.setdefault("m3u_source", "")
        sources = data.setdefault("sources", {})
        for key in DEFAULTS["sources"]:
            sources.setdefault(key, [])
        return data
    except Exception:
        return json.loads(json.dumps(DEFAULTS))

def save_settings(data):
    _ensure_dir()
    with open(SETTINGS_FILE, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
