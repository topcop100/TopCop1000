# -*- coding: utf-8 -*-
import json
import time
from datetime import datetime, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen


def _normalized(entry):
    keys = ("url", "host", "server", "username", "token", "path")
    return tuple(str(entry.get(k, "")).strip().lower() for k in keys)

def find_duplicates(sources):
    seen = {}
    dupes = set()
    for typ, entries in sources.items():
        if typ == "python":
            continue
        for idx, entry in enumerate(entries):
            key = (typ, _normalized(entry))
            if key in seen:
                dupes.add(seen[key])
                dupes.add((typ, idx))
            else:
                seen[key] = (typ, idx)
    return dupes

def _xtream_info(entry):
    base = (entry.get("url") or entry.get("host") or entry.get("server") or "").rstrip("/")
    user = entry.get("username")
    password = entry.get("password")
    if not (base and user and password):
        return {}
    url = base + "/player_api.php?" + urlencode({"username": user, "password": password})
    req = Request(url, headers={"User-Agent": "TopCop1000/0.9.2"})
    with urlopen(req, timeout=8) as resp:
        payload = json.loads(resp.read().decode("utf-8", "replace"))
    ui = payload.get("user_info") or {}
    info = {}
    exp = ui.get("exp_date")
    if exp and str(exp).isdigit():
        ts = int(exp)
        info["expires"] = datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d")
        info["days_left"] = max(0, int((ts - time.time()) // 86400))
    info["active"] = ui.get("active_cons")
    info["max"] = ui.get("max_connections")
    return info

def inspect_entry(portal_type, entry):
    info = {"type": portal_type, "expires": None, "days_left": None, "active": None, "max": None}
    if portal_type == "xtream":
        try:
            info.update(_xtream_info(entry))
        except Exception:
            pass
    return info

def compact_line(info, duplicate=False):
    parts = []
    if duplicate:
        parts.append("⚠️ doppelt")
    if info.get("expires"):
        parts.append("Ablauf %s" % info["expires"])
        if info.get("days_left") is not None:
            parts.append("%s Tage" % info["days_left"])
    else:
        parts.append("Laufzeit n/v")
    active, maximum = info.get("active"), info.get("max")
    if active is not None or maximum is not None:
        parts.append("Connections %s/%s" % (active if active is not None else "?", maximum if maximum is not None else "?"))
        try:
            if int(maximum) > 0 and int(active) >= int(maximum):
                parts.append("🔴 voll belegt")
        except Exception:
            pass
    else:
        parts.append("Connections n/v")
    return " · ".join(parts)
