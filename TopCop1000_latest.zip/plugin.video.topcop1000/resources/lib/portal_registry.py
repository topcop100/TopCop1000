# -*- coding: utf-8 -*-
def get_portal_types():
    return [
        {"id": "stalker", "label": "Stalker / Ministra"},
        {"id": "xtream", "label": "Xtream Codes"},
        {"id": "m3u", "label": "M3U / M3U8"},
        {"id": "enigma2", "label": "Enigma2"},
        {"id": "plex", "label": "Plex"},
        {"id": "python", "label": "Python"},
    ]
