# -*- coding: utf-8 -*-
"""Small Stalker/Ministra client for a user-supplied, authorized portal + MAC.

The client only uses the single MAC address stored by the user.  It does not
scan, guess, rotate or discover credentials.
"""
import json
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


class StalkerError(Exception):
    pass


UA = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250"


def _normalize_base(url):
    url = (url or "").strip().rstrip("/")
    if not url:
        raise StalkerError("Keine Portal-URL hinterlegt.")
    if not url.lower().startswith(("http://", "https://")):
        url = "http://" + url
    return url


def _candidate_endpoints(base):
    """Return common Ministra/Stalker API endpoints without scanning hosts."""
    base = _normalize_base(base)
    parsed = urlparse(base)
    origin = "%s://%s" % (parsed.scheme, parsed.netloc)
    path = (parsed.path or "").rstrip("/")
    low = path.lower()

    # If the user pasted a concrete API file, keep it as the first choice but
    # also try its sibling and the conventional roots.  Older versions stopped
    # after the single pasted endpoint, which made diagnostics misleading.
    roots = []
    direct = []
    if low.endswith("/server/load.php"):
        root = origin + path[:-len("/server/load.php")]
        direct.extend([base, root.rstrip("/") + "/portal.php"])
        roots.append(root)
    elif low.endswith("/portal.php"):
        root = origin + path[:-len("/portal.php")]
        direct.extend([base, root.rstrip("/") + "/server/load.php"])
        roots.append(root)
    else:
        # MAG portal URLs are often supplied as .../c or .../stalker_portal/c.
        if low.endswith("/c"):
            roots.append(origin + path[:-2])
        else:
            roots.append(origin + path)

    roots.extend([origin, origin + "/stalker_portal"])

    candidates = list(direct)
    for root in roots:
        root = root.rstrip("/")
        if not root:
            continue
        candidates.append(root + "/server/load.php")
        candidates.append(root + "/portal.php")

    return list(dict.fromkeys(candidates))


def _portal_referer(endpoint):
    """Build the browser-like /c/ referer expected by many MAG portals."""
    parsed = urlparse(endpoint)
    path = (parsed.path or "").rstrip("/")
    low = path.lower()
    for suffix in ("/server/load.php", "/portal.php"):
        if low.endswith(suffix):
            path = path[:-len(suffix)]
            break
    root = "%s://%s%s" % (parsed.scheme, parsed.netloc, path.rstrip("/"))
    return root.rstrip("/") + "/c/"


def _headers(mac, token=None, endpoint=None):
    headers = {
        "User-Agent": UA,
        "X-User-Agent": "Model: MAG250; Link: Ethernet",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.8",
        "Connection": "keep-alive",
        "Cookie": "mac=%s; stb_lang=en; timezone=Europe/Berlin" % mac,
    }
    if endpoint:
        headers["Referer"] = _portal_referer(endpoint)
    if token:
        headers["Authorization"] = "Bearer " + token
    return headers


def _response_kind(raw, content_type=""):
    text = (raw or "").lstrip()
    ctype = (content_type or "").lower()
    if "html" in ctype or text[:15].lower().startswith(("<!doctype html", "<html")):
        return "HTML statt JSON"
    if not text:
        return "leere Antwort"
    return "kein gültiges JSON"


def _request_json(endpoint, mac, params, token=None, timeout=12):
    query = dict(params)
    query.setdefault("JsHttpRequest", "1-xml")
    url = endpoint + ("&" if "?" in endpoint else "?") + urlencode(query)
    req = Request(url, headers=_headers(mac, token, endpoint))
    try:
        with urlopen(req, timeout=timeout) as resp:
            status = getattr(resp, "status", None) or resp.getcode()
            content_type = resp.headers.get("Content-Type", "") if getattr(resp, "headers", None) else ""
            raw = resp.read().decode("utf-8", "replace")
    except HTTPError as exc:
        # Do not display response bodies because they can contain portal details.
        try:
            body = exc.read().decode("utf-8", "replace")
        except Exception:
            body = ""
        ctype = exc.headers.get("Content-Type", "") if getattr(exc, "headers", None) else ""
        kind = _response_kind(body, ctype)
        raise StalkerError("HTTP %s (%s)" % (exc.code, kind))
    except (URLError, OSError, ValueError) as exc:
        raise StalkerError("nicht erreichbar: %s" % exc)
    try:
        return json.loads(raw)
    except Exception:
        raise StalkerError("HTTP %s (%s)" % (status, _response_kind(raw, content_type)))


def _js(payload):
    if isinstance(payload, dict) and "js" in payload:
        return payload.get("js")
    return payload


def handshake(base_url, mac):
    mac = (mac or "").strip()
    if not mac:
        raise StalkerError("Keine MAC-Adresse hinterlegt.")

    errors = []
    for endpoint in _candidate_endpoints(base_url):
        try:
            payload = _request_json(endpoint, mac, {
                "type": "stb", "action": "handshake", "token": ""
            })
            data = _js(payload) or {}
            token = data.get("token") if isinstance(data, dict) else None
            if token:
                return endpoint, token
            if isinstance(data, dict):
                errors.append("%s -> HTTP 200 (JSON, aber kein Token)" % urlparse(endpoint).path)
            else:
                errors.append("%s -> HTTP 200 (JSON, unerwartetes Format)" % urlparse(endpoint).path)
        except StalkerError as exc:
            errors.append("%s -> %s" % (urlparse(endpoint).path, str(exc)))
    detail = "\n".join(errors[-8:])
    raise StalkerError("Kein passender Stalker-Endpunkt gefunden.\nGetestete API-Pfade:\n%s" % detail)


def get_profile(base_url, mac):
    endpoint, token = handshake(base_url, mac)
    payload = _request_json(endpoint, mac, {
        "type": "stb", "action": "get_profile", "hd": "1"
    }, token=token)
    return _js(payload) or {}, endpoint, token


def get_genres(base_url, mac):
    endpoint, token = handshake(base_url, mac)
    payload = _request_json(endpoint, mac, {
        "type": "itv", "action": "get_genres"
    }, token=token)
    data = _js(payload) or []
    if isinstance(data, dict):
        data = data.get("data") or data.get("genres") or []
    return data if isinstance(data, list) else []


def get_channels(base_url, mac):
    endpoint, token = handshake(base_url, mac)
    payload = _request_json(endpoint, mac, {
        "type": "itv", "action": "get_all_channels"
    }, token=token)
    data = _js(payload) or []
    if isinstance(data, dict):
        data = data.get("data") or data.get("channels") or []
    return data if isinstance(data, list) else []


def create_link(base_url, mac, cmd):
    endpoint, token = handshake(base_url, mac)
    payload = _request_json(endpoint, mac, {
        "type": "itv", "action": "create_link", "cmd": cmd or "",
        "series": "0", "forced_storage": "0", "disable_ad": "0",
        "download": "0"
    }, token=token)
    data = _js(payload) or {}
    if isinstance(data, dict):
        url = data.get("cmd") or data.get("url") or ""
    else:
        url = str(data or "")
    url = url.strip()
    for prefix in ("ffmpeg ", "ffmpeg://"):
        if url.lower().startswith(prefix):
            url = url[len(prefix):].strip()
            break
    if not url:
        raise StalkerError("Portal hat keinen abspielbaren Stream-Link geliefert.")
    return url
