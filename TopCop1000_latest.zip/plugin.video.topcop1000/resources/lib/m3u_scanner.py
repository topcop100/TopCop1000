# -*- coding: utf-8 -*-
import re
from urllib.request import Request, urlopen

EXTINF_RE = re.compile(r'^#EXTINF:(?P<meta>.*?),(?P<name>.*)$')
ATTR_RE = re.compile(r'([\w-]+)="([^"]*)"')

def _read_source(source):
    if source.lower().startswith(("http://", "https://")):
        req = Request(source, headers={"User-Agent": "TopCop1000/0.9.1"})
        with urlopen(req, timeout=12) as resp:
            return resp.read().decode("utf-8", "replace")
    with open(source, "r", encoding="utf-8", errors="replace") as fh:
        return fh.read()

def load_m3u(source):
    text = _read_source(source)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    result = []
    current = None
    for line in lines:
        if line.startswith("#EXTINF"):
            m = EXTINF_RE.match(line)
            if not m:
                current = None
                continue
            attrs = dict(ATTR_RE.findall(m.group("meta")))
            current = {
                "name": m.group("name").strip() or attrs.get("tvg-name", "Unbenannt"),
                "group": attrs.get("group-title", ""),
                "logo": attrs.get("tvg-logo", ""),
                "url": ""
            }
        elif not line.startswith("#") and current is not None:
            current["url"] = line
            result.append(current)
            current = None
    return result

def _section(entry):
    text = (entry.get("group", "") + " " + entry.get("name", "")).lower()
    if any(x in text for x in ("series", "serie", "tv shows", "episode", "staffel")):
        return "series"
    if any(x in text for x in ("movie", "movies", "film", "cinema", "vod")):
        return "movies"
    return "tv"

def group_entries(entries):
    grouped = {"tv": [], "movies": [], "series": []}
    for entry in entries:
        grouped[_section(entry)].append(entry)
    return grouped
