# -*- coding: utf-8 -*-
import os
import xbmcvfs

def output_root():
    path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.topcop1000/outputs/")
    os.makedirs(path, exist_ok=True)
    return path

def list_outputs():
    root = output_root()
    result = {}
    for group in sorted(os.listdir(root)):
        gpath = os.path.join(root, group)
        if not os.path.isdir(gpath):
            continue
        items = []
        for name in sorted(os.listdir(gpath)):
            path = os.path.join(gpath, name)
            if os.path.isfile(path):
                items.append({"name": name, "path": path})
        result[group] = items
    return result
