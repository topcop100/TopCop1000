# -*- coding: utf-8 -*-
import time
from datetime import datetime
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from resources.lib.stalker_client import handshake, StalkerError


def _base(entry):
    return (entry.get("url") or entry.get("host") or entry.get("server") or "").rstrip("/")

def _target(portal_type, entry):
    base = _base(entry)
    if portal_type == "xtream" and base and entry.get("username") and entry.get("password"):
        return base + "/player_api.php?" + urlencode({"username": entry["username"], "password": entry["password"]})
    if portal_type == "enigma2" and base:
        return base + "/web/about"
    if portal_type == "plex" and base:
        return base + "/identity"
    return entry.get("url") or base

def check_entry(portal_type, entry):
    # Stalker/Ministra must be checked through the portal handshake, not by
    # opening the bare portal URL (many valid portals return 401/403 there).
    if portal_type == "stalker":
        started = time.time()
        try:
            endpoint, token = handshake(entry.get("url", ""), entry.get("mac", ""))
            ms = int((time.time() - started) * 1000)
            return {"status": "online", "message": "Stalker-Anmeldung erfolgreich", "ms": ms, "http_code": None, "checked_at": datetime.now().strftime("%d.%m.%Y %H:%M:%S")}
        except StalkerError as exc:
            ms = int((time.time() - started) * 1000)
            return {"status": "auth", "message": str(exc), "ms": ms, "http_code": None, "checked_at": datetime.now().strftime("%d.%m.%Y %H:%M:%S")}

    target = _target(portal_type, entry)
    if not target:
        return {"status": "warning", "message": "Keine URL hinterlegt", "ms": None, "http_code": None, "checked_at": datetime.now().strftime("%d.%m.%Y %H:%M:%S")}
    headers = {"User-Agent": "TopCop1000/0.9.14"}
    token = entry.get("token")
    if portal_type == "plex" and token:
        headers["X-Plex-Token"] = token
    started = time.time()
    try:
        req = Request(target, headers=headers)
        with urlopen(req, timeout=8) as resp:
            code = getattr(resp, "status", 200)
            resp.read(1024)
        ms = int((time.time() - started) * 1000)
        return {"status": "online", "message": "Erreichbar", "ms": ms, "http_code": code, "checked_at": datetime.now().strftime("%d.%m.%Y %H:%M:%S")}
    except HTTPError as exc:
        ms = int((time.time() - started) * 1000)
        if exc.code in (401, 403):
            return {"status": "auth", "message": "Login/Token abgelehnt", "ms": ms, "http_code": exc.code, "checked_at": datetime.now().strftime("%d.%m.%Y %H:%M:%S")}
        return {"status": "warning", "message": "Server antwortet mit Fehler", "ms": ms, "http_code": exc.code, "checked_at": datetime.now().strftime("%d.%m.%Y %H:%M:%S")}
    except (URLError, OSError, ValueError) as exc:
        ms = int((time.time() - started) * 1000)
        return {"status": "offline", "message": str(exc), "ms": ms, "http_code": None, "checked_at": datetime.now().strftime("%d.%m.%Y %H:%M:%S")}

def status_label(result):
    states = {"online": "ONLINE", "offline": "OFFLINE", "auth": "ANMELDUNG FEHLER", "warning": "WARNUNG"}
    status = result.get("status")
    lines = [states.get(status, "UNBEKANNT")]
    message = result.get("message")
    if message:
        lines.append(str(message))
    if result.get("http_code") is not None:
        lines.append("HTTP-Code: %s" % result["http_code"])
    if result.get("ms") is not None:
        lines.append("Antwortzeit: %d ms" % result["ms"])
    if result.get("checked_at"):
        lines.append("Letzte Pruefung: %s" % result["checked_at"])
    return "\n".join(lines)
