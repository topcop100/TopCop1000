# -*- coding: utf-8 -*-
"""Conservative dependency helper for the TopCop1000 Python portal.

Only pure-Python universal wheels are installed automatically. Native/binary wheels,
source distributions and unsafe ZIP paths are deliberately rejected.
"""

import ast
import hashlib
import importlib
import importlib.util
import json
import os
import re
import shutil
import sys
import tempfile
import time
import zipfile
from urllib.request import Request, urlopen

ADDON_ID = "plugin.video.topcop1000"
MAX_INDEX_BYTES = 8 * 1024 * 1024
MAX_WHEEL_BYTES = 50 * 1024 * 1024
MAX_PACKAGE_FILES = 5000
MAX_PACKAGE_UNPACKED = 150 * 1024 * 1024
MAX_DEPENDENCY_DEPTH = 5
MAX_DEPENDENCY_PACKAGES = 20

# Kodi/TopCop runtime modules that are not PyPI dependencies.
_PLATFORM_MODULES = {
    "xbmc", "xbmcaddon", "xbmcgui", "xbmcplugin", "xbmcvfs", "jnius",
}

# Import name -> PyPI project name. Keep this list conservative and pure-Python.
_SAFE_PYPI_MAP = {
    "requests": "requests",
    "urllib3": "urllib3",
    "certifi": "certifi",
    "idna": "idna",
    "charset_normalizer": "charset-normalizer",
    "chardet": "chardet",
    "six": "six",
    "dateutil": "python-dateutil",
    "bs4": "beautifulsoup4",
    "soupsieve": "soupsieve",
    "websocket": "websocket-client",
    "m3u8": "m3u8",
    "typing_extensions": "typing-extensions",
}

# Fallback for Python versions without sys.stdlib_module_names.
_STDLIB_FALLBACK = {
    "abc", "argparse", "array", "ast", "asyncio", "base64", "binascii",
    "bisect", "builtins", "calendar", "collections", "concurrent", "contextlib",
    "copy", "csv", "ctypes", "datetime", "decimal", "email", "enum", "errno",
    "fnmatch", "fractions", "functools", "gc", "getopt", "getpass", "glob",
    "gzip", "hashlib", "heapq", "hmac", "html", "http", "importlib", "inspect",
    "io", "ipaddress", "itertools", "json", "logging", "lzma", "math", "mimetypes",
    "multiprocessing", "operator", "os", "pathlib", "pickle", "pkgutil", "platform",
    "plistlib", "queue", "random", "re", "secrets", "select", "shlex", "shutil",
    "signal", "socket", "sqlite3", "ssl", "statistics", "string", "struct", "subprocess",
    "sys", "tempfile", "textwrap", "threading", "time", "traceback", "types", "typing",
    "unicodedata", "urllib", "uuid", "warnings", "weakref", "xml", "zipfile", "zlib",
}


def _profile_dir():
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(
            "special://profile/addon_data/%s/" % ADDON_ID
        )
    except Exception:
        return os.path.join(os.path.expanduser("~"), ".topcop1000")


def package_dir():
    return os.path.join(_profile_dir(), "python_packages")


def script_packages_dir():
    return os.path.join(_profile_dir(), "python_script_packages")


def log_path():
    return os.path.join(_profile_dir(), "python_installer.log")


def ensure_package_path():
    target = package_dir()
    os.makedirs(target, exist_ok=True)
    if target not in sys.path:
        sys.path.insert(0, target)
    importlib.invalidate_caches()
    return target


def log(message):
    try:
        os.makedirs(_profile_dir(), exist_ok=True)
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path(), "a", encoding="utf-8") as fh:
            fh.write("[%s] %s\n" % (stamp, str(message)))
    except Exception:
        pass


def read_log(max_lines=80):
    try:
        with open(log_path(), "r", encoding="utf-8") as fh:
            lines = fh.read().splitlines()
        return "\n".join(lines[-max_lines:])
    except Exception:
        return "Noch kein Installationsprotokoll vorhanden."


def _stdlib_names():
    names = set(_STDLIB_FALLBACK)
    try:
        names.update(sys.builtin_module_names)
    except Exception:
        pass
    try:
        names.update(sys.stdlib_module_names)
    except Exception:
        pass
    return names


def _top_name(name):
    return (name or "").split(".", 1)[0].strip()


def _imports_from_source(source, filename="<python>"):
    try:
        tree = ast.parse(source, filename=filename)
    except Exception as exc:
        return set(), "%s: %s" % (os.path.basename(filename), exc)

    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                top = _top_name(alias.name)
                if top:
                    imports.add(top)
        elif isinstance(node, ast.ImportFrom):
            if int(getattr(node, "level", 0) or 0) > 0:
                continue
            top = _top_name(getattr(node, "module", ""))
            if top:
                imports.add(top)
    return imports, None


def _read_python(path):
    with open(path, "rb") as fh:
        raw = fh.read()
    try:
        return raw.decode("utf-8-sig")
    except Exception:
        return raw.decode("utf-8", "replace")


def _local_top_level_names(root):
    names = set()
    try:
        for name in os.listdir(root):
            full = os.path.join(root, name)
            if os.path.isfile(full) and name.lower().endswith(".py"):
                names.add(os.path.splitext(name)[0])
            elif os.path.isdir(full):
                # Treat a top-level directory as local. This also covers namespace packages.
                names.add(name)
    except Exception:
        pass
    return names


def _is_importable(name):
    ensure_package_path()
    try:
        if name in sys.modules:
            return True
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False


def classify_imports(imports, local_names=None):
    stdlib = _stdlib_names()
    local = set(local_names or [])
    result = {
        "imports": sorted(set(imports)),
        "standard": [],
        "local": [],
        "present": [],
        "missing": [],
        "auto_installable": [],
        "unresolved": [],
        "parse_errors": [],
    }

    for name in result["imports"]:
        if name in _PLATFORM_MODULES or name in stdlib:
            result["standard"].append(name)
        elif name in local:
            result["local"].append(name)
        elif _is_importable(name):
            result["present"].append(name)
        else:
            result["missing"].append(name)
            if name in _SAFE_PYPI_MAP:
                result["auto_installable"].append(name)
            else:
                result["unresolved"].append(name)
    return result


def analyze_python_file(path, local_names=None):
    source = _read_python(path)
    imports, error = _imports_from_source(source, path)
    names = set(local_names or [])
    names.add(os.path.splitext(os.path.basename(path))[0])
    result = classify_imports(imports, names)
    if error:
        result["parse_errors"].append(error)
    result["file_count"] = 1
    result["label"] = os.path.basename(path)
    return result


def analyze_python_tree(root):
    imports = set()
    parse_errors = []
    file_count = 0
    local_names = _local_top_level_names(root)

    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d != "__pycache__" and not d.endswith(".dist-info")]
        for filename in files:
            if not filename.lower().endswith(".py"):
                continue
            file_count += 1
            path = os.path.join(base, filename)
            try:
                found, error = _imports_from_source(_read_python(path), path)
                imports.update(found)
                if error:
                    parse_errors.append(error)
            except Exception as exc:
                parse_errors.append("%s: %s" % (filename, exc))

    result = classify_imports(imports, local_names)
    result["parse_errors"].extend(parse_errors)
    result["file_count"] = file_count
    result["label"] = os.path.basename(root.rstrip("/\\")) or root
    return result


def report_ok(report):
    return not report.get("missing") and not report.get("parse_errors")


def format_report(report, label=None):
    label = label or report.get("label") or "Python-Paket"
    present_count = len(report.get("standard", [])) + len(report.get("local", [])) + len(report.get("present", []))
    lines = [
        "Datei/Paket: %s" % label,
        "Python-Dateien: %d" % int(report.get("file_count", 0)),
        "Erkannte Imports: %d" % len(report.get("imports", [])),
        "Vorhanden/OK: %d" % present_count,
        "",
        "Fehlende Module: %s" % (", ".join(report.get("missing", [])) or "keine"),
        "Automatisch installierbar: %s" % (", ".join(report.get("auto_installable", [])) or "keine"),
        "Nicht automatisch installierbar: %s" % (", ".join(report.get("unresolved", [])) or "keine"),
    ]
    if report.get("parse_errors"):
        lines.extend(["", "Prüf-/Syntaxwarnungen:"] + report["parse_errors"][:6])
    return "\n".join(lines)


def _request_bytes(url, max_bytes, timeout=20):
    req = Request(url, headers={"User-Agent": "TopCop1000-PythonInstaller/1.0"})
    response = urlopen(req, timeout=timeout)
    try:
        total = 0
        chunks = []
        while True:
            chunk = response.read(256 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise RuntimeError("Download ist größer als die erlaubte Schutzgrenze.")
            chunks.append(chunk)
        return b"".join(chunks)
    finally:
        try:
            response.close()
        except Exception:
            pass


def _safe_project_name(value):
    value = str(value or "").strip()
    if not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,100}$", value):
        raise RuntimeError("Ungültiger Paketname.")
    return value


def _choose_universal_wheel(project):
    project = _safe_project_name(project)
    url = "https://pypi.org/pypi/%s/json" % project
    try:
        payload = _request_bytes(url, MAX_INDEX_BYTES, timeout=15)
        data = json.loads(payload.decode("utf-8"))
    except Exception as exc:
        raise RuntimeError("PyPI-Abfrage für %s fehlgeschlagen: %s" % (project, exc))

    candidates = []
    for item in data.get("urls", []):
        filename = str(item.get("filename") or "")
        low = filename.lower()
        if item.get("packagetype") != "bdist_wheel":
            continue
        if not low.endswith("none-any.whl"):
            continue
        if "py3-" not in low and "py2.py3-" not in low:
            continue
        candidates.append(item)

    if not candidates:
        raise RuntimeError(
            "%s bietet für die aktuelle Version kein reines Python-Universal-Wheel. "
            "Binärpakete und Quellcode-Builds werden aus Sicherheitsgründen nicht automatisch installiert."
            % project
        )

    candidates.sort(key=lambda x: str(x.get("filename") or ""))
    return candidates[-1]


def _wheel_requirements(zf):
    metadata = [n for n in zf.namelist() if n.endswith(".dist-info/METADATA")]
    if not metadata:
        return []
    try:
        text = zf.read(metadata[0]).decode("utf-8", "replace")
    except Exception:
        return []
    reqs = []
    for line in text.splitlines():
        if not line.startswith("Requires-Dist:"):
            continue
        value = line.split(":", 1)[1].strip()
        # Optional extras are not needed for normal imports.
        if ";" in value and "extra" in value.lower():
            continue
        match = re.match(r"([A-Za-z0-9][A-Za-z0-9_.-]*)", value)
        if match:
            reqs.append(match.group(1))
    return sorted(set(reqs))


def _validate_wheel(zf):
    total = 0
    count = 0
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")
        if not name or name.endswith("/"):
            continue
        count += 1
        total += int(info.file_size or 0)
        if count > MAX_PACKAGE_FILES:
            raise RuntimeError("Paket enthält zu viele Dateien.")
        if total > MAX_PACKAGE_UNPACKED:
            raise RuntimeError("Entpacktes Paket wäre zu groß.")
        parts = [p for p in name.split("/") if p not in ("", ".")]
        if name.startswith("/") or any(p == ".." for p in parts):
            raise RuntimeError("Unsicherer Pfad im Python-Paket.")
        mode = (int(info.external_attr or 0) >> 16) & 0o170000
        if mode == 0o120000:
            raise RuntimeError("Symbolische Links in Python-Paketen werden nicht automatisch installiert.")
        low = name.lower()
        if low.endswith((".so", ".pyd", ".dll", ".dylib", ".exe")):
            raise RuntimeError("Binärdatei im Paket gefunden: %s" % name)


def _extract_wheel_bytes(wheel_bytes, target):
    os.makedirs(target, exist_ok=True)
    fd, temp_path = tempfile.mkstemp(prefix="topcop_wheel_", suffix=".whl")
    os.close(fd)
    try:
        with open(temp_path, "wb") as fh:
            fh.write(wheel_bytes)
        with zipfile.ZipFile(temp_path, "r") as zf:
            _validate_wheel(zf)
            requirements = _wheel_requirements(zf)
            dest_real = os.path.realpath(target)
            for info in zf.infolist():
                name = info.filename.replace("\\", "/")
                if not name or name.endswith("/"):
                    continue
                parts = [p for p in name.split("/") if p not in ("", ".")]
                # Wheel .data/purelib content belongs directly in the target site path.
                if len(parts) >= 3 and parts[0].endswith(".data"):
                    if parts[1] == "purelib":
                        parts = parts[2:]
                    else:
                        # Do not install scripts, headers, platform data or platlib payloads.
                        continue
                if not parts:
                    continue
                out = os.path.realpath(os.path.join(target, *parts))
                if out != dest_real and not out.startswith(dest_real + os.sep):
                    raise RuntimeError("Unsicherer Zielpfad im Python-Paket.")
                os.makedirs(os.path.dirname(out), exist_ok=True)
                with zf.open(info, "r") as src, open(out, "wb") as dst:
                    shutil.copyfileobj(src, dst, length=256 * 1024)
            return requirements
    finally:
        try:
            os.remove(temp_path)
        except Exception:
            pass


def install_pure_pypi_package(project, _visited=None, _depth=0):
    """Install a project from PyPI only when a py3/py2.py3 none-any wheel exists."""
    project = _safe_project_name(project)
    visited = _visited if _visited is not None else set()
    norm = re.sub(r"[-_.]+", "-", project).lower()
    if norm in visited:
        return
    if len(visited) >= MAX_DEPENDENCY_PACKAGES:
        raise RuntimeError("Zu viele Paketabhängigkeiten; Installation wurde gestoppt.")
    if _depth > MAX_DEPENDENCY_DEPTH:
        raise RuntimeError("Abhängigkeitstiefe zu groß; Installation wurde gestoppt.")
    visited.add(norm)

    wheel = _choose_universal_wheel(project)
    filename = str(wheel.get("filename") or project)
    url = str(wheel.get("url") or "")
    expected = str((wheel.get("digests") or {}).get("sha256") or "").lower()
    if not url.startswith("https://"):
        raise RuntimeError("Unsichere Download-Adresse für %s." % project)

    log("Lade reines Python-Paket %s (%s)" % (project, filename))
    wheel_bytes = _request_bytes(url, MAX_WHEEL_BYTES, timeout=25)
    if expected:
        actual = hashlib.sha256(wheel_bytes).hexdigest().lower()
        if actual != expected:
            raise RuntimeError("SHA256-Prüfung für %s fehlgeschlagen." % project)

    # Inspect requirements before/while extracting. Installing dependencies first makes
    # the final import test deterministic.
    fd, inspect_path = tempfile.mkstemp(prefix="topcop_inspect_", suffix=".whl")
    os.close(fd)
    try:
        with open(inspect_path, "wb") as fh:
            fh.write(wheel_bytes)
        with zipfile.ZipFile(inspect_path, "r") as zf:
            _validate_wheel(zf)
            requirements = _wheel_requirements(zf)
    finally:
        try:
            os.remove(inspect_path)
        except Exception:
            pass

    for requirement in requirements:
        install_pure_pypi_package(requirement, visited, _depth + 1)

    target = ensure_package_path()
    _extract_wheel_bytes(wheel_bytes, target)
    importlib.invalidate_caches()
    log("Installiert: %s (%s)" % (project, filename))


def install_import(import_name):
    import_name = _top_name(import_name)
    if _is_importable(import_name):
        return True, "%s ist bereits vorhanden." % import_name
    project = _SAFE_PYPI_MAP.get(import_name)
    if not project:
        return False, "%s ist nicht für die automatische Installation freigegeben." % import_name
    try:
        install_pure_pypi_package(project)
        ok = _is_importable(import_name)
        if ok:
            return True, "%s wurde installiert." % import_name
        return False, "%s wurde geladen, ist aber noch nicht importierbar." % import_name
    except Exception as exc:
        log("Fehler bei %s: %s" % (import_name, exc))
        return False, "%s: %s" % (import_name, exc)


def install_missing_modules(report):
    results = []
    for name in report.get("auto_installable", []):
        ok, message = install_import(name)
        results.append((name, ok, message))
    return results


def manual_install(project):
    try:
        install_pure_pypi_package(project)
        return True, "%s wurde in den TopCop1000-Paketordner installiert." % project
    except Exception as exc:
        log("Manuelle Installation fehlgeschlagen (%s): %s" % (project, exc))
        return False, str(exc)


def prepare_python_zip(zip_path, work_parent):
    """Safely extract a controlled Python ZIP and determine its entrypoint.

    Supported layouts:
      - topcop-package.json with {"name": "...", "entry": "main.py"}
      - main.py in ZIP root
      - exactly one .py file in ZIP root
    """
    if not os.path.isfile(zip_path):
        raise RuntimeError("ZIP-Datei wurde nicht gefunden.")
    os.makedirs(work_parent, exist_ok=True)
    work = tempfile.mkdtemp(prefix="topcop_pyzip_", dir=work_parent)
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            total = 0
            count = 0
            for info in zf.infolist():
                name = info.filename.replace("\\", "/")
                if not name:
                    continue
                count += 1
                total += int(info.file_size or 0)
                if count > MAX_PACKAGE_FILES or total > MAX_PACKAGE_UNPACKED:
                    raise RuntimeError("PY-ZIP überschreitet die Schutzgrenze.")
                parts = [p for p in name.split("/") if p not in ("", ".")]
                if name.startswith("/") or any(p == ".." for p in parts):
                    raise RuntimeError("Unsicherer Pfad in PY-ZIP.")
                mode = (int(info.external_attr or 0) >> 16) & 0o170000
                if mode == 0o120000:
                    raise RuntimeError("Symbolische Links sind in PY-ZIPs nicht erlaubt.")
            zf.extractall(work)

        manifest_path = os.path.join(work, "topcop-package.json")
        manifest = {}
        if os.path.isfile(manifest_path):
            try:
                with open(manifest_path, "r", encoding="utf-8") as fh:
                    manifest = json.load(fh)
                if not isinstance(manifest, dict):
                    manifest = {}
            except Exception as exc:
                raise RuntimeError("topcop-package.json ist ungültig: %s" % exc)

        base_name = os.path.splitext(os.path.basename(zip_path))[0]
        package_name = str(manifest.get("name") or base_name).strip()
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", package_name).strip("._-") or "python_package"
        entry = str(manifest.get("entry") or "").replace("\\", "/").strip("/")

        if not entry:
            if os.path.isfile(os.path.join(work, "main.py")):
                entry = "main.py"
            else:
                root_py = [n for n in os.listdir(work) if n.lower().endswith(".py") and os.path.isfile(os.path.join(work, n))]
                if len(root_py) == 1:
                    entry = root_py[0]

        if not entry:
            raise RuntimeError(
                "PY-ZIP hat keinen eindeutigen Startpunkt. Verwende main.py oder topcop-package.json."
            )
        parts = [p for p in entry.split("/") if p not in ("", ".")]
        if any(p == ".." for p in parts):
            raise RuntimeError("Unsicherer Startpfad im PY-ZIP.")
        entry_path = os.path.realpath(os.path.join(work, *parts))
        work_real = os.path.realpath(work)
        if entry_path != work_real and not entry_path.startswith(work_real + os.sep):
            raise RuntimeError("Startdatei liegt außerhalb des PY-ZIP-Pakets.")
        if not os.path.isfile(entry_path) or not entry_path.lower().endswith(".py"):
            raise RuntimeError("Startdatei des PY-ZIP-Pakets wurde nicht gefunden.")

        return {"work": work, "name": safe_name, "entry": entry, "entry_path": entry_path}
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise
