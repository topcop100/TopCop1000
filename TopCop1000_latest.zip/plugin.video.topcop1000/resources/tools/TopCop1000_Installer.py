# -*- coding: utf-8 -*-
"""
TopCop1000 - permanenter Installer / Updater

Zweck:
- vollständige TopCop1000-Update-ZIPs sicher installieren
- bestehende Plugin-Dateien vor jedem Update sichern
- persönliche Daten unter userdata/addon_data NICHT verändern
- letzte Sicherung bei Bedarf wiederherstellen
- feste GitHub-/Download-Adresse speichern

Die Update-ZIP muss eine gültige Kodi-Add-on-Struktur enthalten:
  plugin.video.topcop1000/addon.xml
oder addon.xml direkt im ZIP-Hauptverzeichnis.

Dieses Skript gehört ins TopCop1000 Python-Portal (modules).
"""

import os
import re
import json
import time
import shutil
import zipfile
import tempfile
import xml.etree.ElementTree as ET
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib.python_package_installer import (
    analyze_python_tree, format_report, install_missing_modules, manual_install,
    package_dir, report_ok,
)

ADDON_ID = "plugin.video.topcop1000"
DEFAULT_UPDATE_URL = "https://raw.githubusercontent.com/topcop100/TopCop1000/main/TopCop1000_latest.zip"
MAX_ZIP_BYTES = 250 * 1024 * 1024
MAX_UNPACKED_BYTES = 500 * 1024 * 1024

PROFILE_DIR = xbmcvfs.translatePath(
    "special://profile/addon_data/%s/" % ADDON_ID
)
ADDON_DIR = xbmcvfs.translatePath(
    "special://home/addons/%s/" % ADDON_ID
)
BACKUP_DIR = os.path.join(PROFILE_DIR, "installer_backups")
CONFIG_PATH = os.path.join(PROFILE_DIR, "installer_config.json")
PHONE_PASTE = os.path.join(PROFILE_DIR, "phone_paste.txt")


def _mkdirs():
    os.makedirs(PROFILE_DIR, exist_ok=True)
    os.makedirs(BACKUP_DIR, exist_ok=True)


def _dialog():
    return xbmcgui.Dialog()


def _notify(message, ms=3000):
    _dialog().notification("TopCop1000 Installer", message, time=ms)


def _safe_text(value):
    return str(value or "").strip()


def _load_config():
    _mkdirs()
    data = {}
    if os.path.isfile(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
                loaded = json.load(fh)
            if isinstance(loaded, dict):
                data = loaded
        except Exception:
            data = {}

    # Standard-Adresse für neue bzw. noch nicht konfigurierte Installationen.
    # Ein bewusst leer gespeicherter Wert bleibt leer.
    if "update_url" not in data:
        data["update_url"] = DEFAULT_UPDATE_URL
    return data


def _save_config(data):
    _mkdirs()
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, CONFIG_PATH)


def _addon_xml_info(path):
    if not os.path.isfile(path):
        raise RuntimeError("addon.xml fehlt.")
    try:
        root = ET.parse(path).getroot()
    except Exception as exc:
        raise RuntimeError("addon.xml konnte nicht gelesen werden: %s" % exc)

    addon_id = _safe_text(root.attrib.get("id"))
    version = _safe_text(root.attrib.get("version")) or "unbekannt"
    name = _safe_text(root.attrib.get("name")) or ADDON_ID
    return addon_id, version, name


def _current_info():
    try:
        addon_id, version, name = _addon_xml_info(
            os.path.join(ADDON_DIR, "addon.xml")
        )
        return {
            "installed": addon_id == ADDON_ID,
            "id": addon_id,
            "version": version,
            "name": name,
        }
    except Exception:
        return {
            "installed": os.path.isdir(ADDON_DIR),
            "id": ADDON_ID,
            "version": "unbekannt",
            "name": "TopCop1000",
        }


def _version_key(value):
    parts = re.findall(r"\d+|[A-Za-z]+", _safe_text(value))
    key = []
    for part in parts:
        if part.isdigit():
            key.append((0, int(part)))
        else:
            key.append((1, part.lower()))
    return tuple(key)


def _read_phone_paste():
    try:
        with open(PHONE_PASTE, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    except Exception:
        return ""


def _set_update_url():
    cfg = _load_config()
    current = _safe_text(cfg.get("update_url"))

    choices = [
        "Adresse eingeben / bearbeiten",
        "Vom Handy Copy & Paste übernehmen",
        "Gespeicherte Adresse anzeigen",
        "Gespeicherte Adresse löschen",
    ]
    pos = _dialog().select("TopCop1000 - Update-Adresse", choices)
    if pos < 0:
        return

    if pos == 0:
        value = _dialog().input(
            "Direkte ZIP-Download-Adresse",
            defaultt=current,
            type=xbmcgui.INPUT_ALPHANUM,
        )
        value = _safe_text(value)
        if value:
            cfg["update_url"] = value
            _save_config(cfg)
            _notify("Update-Adresse gespeichert.")
        return

    if pos == 1:
        value = _read_phone_paste()
        if not value:
            _dialog().ok(
                "TopCop1000 Installer",
                "In Handy Copy & Paste wurde noch keine Adresse empfangen."
            )
            return
        if "\n" in value:
            value = value.splitlines()[0].strip()
        if not (value.startswith("http://") or value.startswith("https://")):
            _dialog().ok(
                "TopCop1000 Installer",
                "Der empfangene Text ist keine HTTP/HTTPS-Adresse."
            )
            return
        cfg["update_url"] = value
        _save_config(cfg)
        _notify("Update-Adresse vom Handy gespeichert.")
        return

    if pos == 2:
        _dialog().ok(
            "TopCop1000 Installer",
            current if current else "Noch keine Update-Adresse gespeichert."
        )
        return

    if pos == 3:
        # Leeren Wert ausdrücklich speichern, damit die Standard-Adresse
        # nicht sofort wieder als Fallback erscheint.
        cfg["update_url"] = ""
        _save_config(cfg)
        _notify("Update-Adresse gelöscht.")


def _download(url, destination):
    req = Request(
        url,
        headers={
            "User-Agent": "TopCop1000-Installer/1.0",
            "Accept": "application/zip, application/octet-stream, */*",
        },
    )

    try:
        response = urlopen(req, timeout=20)
    except Exception as exc:
        raise RuntimeError("Download konnte nicht gestartet werden: %s" % exc)

    total = 0
    try:
        length = response.headers.get("Content-Length")
        if length:
            try:
                if int(length) > MAX_ZIP_BYTES:
                    raise RuntimeError("Update-ZIP ist größer als 250 MB.")
            except ValueError:
                pass

        with open(destination, "wb") as fh:
            while True:
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_ZIP_BYTES:
                    raise RuntimeError("Update-ZIP ist größer als 250 MB.")
                fh.write(chunk)
    finally:
        try:
            response.close()
        except Exception:
            pass

    if total == 0:
        raise RuntimeError("Der Download war leer.")


def _zip_layout(zf):
    names = [n.replace("\\", "/") for n in zf.namelist() if n and not n.endswith("/")]

    candidates = [
        "%s/addon.xml" % ADDON_ID,
        "addon.xml",
    ]

    xml_name = None
    for candidate in candidates:
        if candidate in names:
            xml_name = candidate
            break

    if not xml_name:
        raise RuntimeError(
            "Ungültige Update-ZIP: addon.xml für %s wurde nicht gefunden." % ADDON_ID
        )

    if xml_name == "addon.xml":
        prefix = ""
    else:
        prefix = ADDON_ID + "/"

    total_unpacked = 0
    for info in zf.infolist():
        if info.is_dir():
            continue
        total_unpacked += int(info.file_size or 0)
        if total_unpacked > MAX_UNPACKED_BYTES:
            raise RuntimeError("Entpackte Update-Dateien wären größer als 500 MB.")

    try:
        xml_bytes = zf.read(xml_name)
        xml_root = ET.fromstring(xml_bytes)
    except Exception as exc:
        raise RuntimeError("addon.xml in der ZIP ist ungültig: %s" % exc)

    addon_id = _safe_text(xml_root.attrib.get("id"))
    version = _safe_text(xml_root.attrib.get("version")) or "unbekannt"
    name = _safe_text(xml_root.attrib.get("name")) or ADDON_ID

    if addon_id != ADDON_ID:
        raise RuntimeError(
            "Falsches Add-on in der ZIP: %s" % (addon_id or "keine ID")
        )

    return prefix, version, name


def _safe_extract_plugin(zf, prefix, destination):
    os.makedirs(destination, exist_ok=True)
    dest_real = os.path.realpath(destination)

    extracted = 0
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")

        if prefix:
            if not name.startswith(prefix):
                continue
            rel = name[len(prefix):]
        else:
            rel = name

        rel = rel.lstrip("/")
        if not rel:
            continue

        # Keine Pfad-Traversierung.
        parts = [p for p in rel.split("/") if p not in ("", ".")]
        if any(p == ".." for p in parts):
            raise RuntimeError("Unsicherer Pfad in Update-ZIP.")
        rel = os.path.join(*parts) if parts else ""
        if not rel:
            continue

        target = os.path.realpath(os.path.join(destination, rel))
        if target != dest_real and not target.startswith(dest_real + os.sep):
            raise RuntimeError("Unsicherer Pfad in Update-ZIP.")

        if info.is_dir() or name.endswith("/"):
            os.makedirs(target, exist_ok=True)
            continue

        os.makedirs(os.path.dirname(target), exist_ok=True)
        with zf.open(info, "r") as src, open(target, "wb") as dst:
            shutil.copyfileobj(src, dst, length=1024 * 256)

        extracted += 1

    if extracted == 0:
        raise RuntimeError("Die ZIP enthielt keine installierbaren Dateien.")


def _backup_current():
    _mkdirs()

    if not os.path.isdir(ADDON_DIR):
        return None

    stamp = time.strftime("%Y%m%d_%H%M%S")
    current = _current_info()
    safe_version = re.sub(r"[^A-Za-z0-9._-]+", "_", current.get("version", "unbekannt"))
    backup_path = os.path.join(
        BACKUP_DIR,
        "TopCop1000_backup_%s_v%s.zip" % (stamp, safe_version)
    )

    with zipfile.ZipFile(
        backup_path, "w", compression=zipfile.ZIP_DEFLATED
    ) as zf:
        for base, dirs, files in os.walk(ADDON_DIR):
            # Python-Cache muss nicht gesichert werden.
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for filename in files:
                if filename.endswith(".pyc"):
                    continue
                full = os.path.join(base, filename)
                rel = os.path.relpath(full, ADDON_DIR)
                zf.write(full, arcname=rel)

    return backup_path



def _dependency_gate_staged(staged, label):
    """Check Python dependencies before replacing the installed TopCop1000 code."""
    dlg = _dialog()
    while True:
        report = analyze_python_tree(staged)
        if report_ok(report):
            return True

        choices = [
            "Abbrechen",
            "Details anzeigen",
            "Fehlende Module installieren",
            "Paketname manuell installieren",
            "Trotzdem installieren - auf eigenes Risiko",
        ]
        pos = dlg.select("TopCop1000 - Abhängigkeitsprüfung", choices)
        if pos < 0 or pos == 0:
            return False
        if pos == 1:
            try:
                dlg.textviewer(
                    "TopCop1000 - Abhängigkeitsdetails",
                    format_report(report, label)
                )
            except Exception:
                dlg.ok("TopCop1000 - Abhängigkeitsdetails", format_report(report, label))
            continue
        if pos == 2:
            results = install_missing_modules(report)
            if not results:
                dlg.ok(
                    "TopCop1000 - Modulinstallation",
                    "Für die fehlenden Module ist keine sichere automatische Installation freigegeben.\n\n"
                    "Du kannst einen PyPI-Paketnamen manuell eingeben oder auf eigenes Risiko fortfahren."
                )
                continue
            lines = []
            for name, ok, message in results:
                lines.append(("OK: " if ok else "FEHLER: ") + message)
            dlg.ok("TopCop1000 - Modulinstallation", "\n".join(lines))
            continue
        if pos == 3:
            if not dlg.yesno(
                "TopCop1000 - Manuelle Modulinstallation",
                "Nur reine Python-Universal-Wheels werden akzeptiert.\n"
                "Binärpakete und Quellcode-Builds werden abgelehnt.\n\n"
                "PyPI-Paketname selbst eingeben?"
            ):
                continue
            project = (dlg.input(
                "PyPI-Paketname eingeben",
                type=xbmcgui.INPUT_ALPHANUM
            ) or "").strip()
            if not project:
                continue
            ok, message = manual_install(project)
            dlg.ok(
                "TopCop1000 - Modulinstallation",
                ("Erfolgreich.\n\n" if ok else "Nicht installiert.\n\n") + message
            )
            continue
        if pos == 4:
            return dlg.yesno(
                "TopCop1000 - WARNUNG",
                "Dieses Update enthält fehlende oder nicht vollständig prüfbare Abhängigkeiten. "
                "Die Installation kann fehlschlagen oder TopCop1000 kann anschließend nicht funktionieren.\n\n"
                "Fortfahren erfolgt auf eigenes Risiko.\n\n"
                "Trotzdem installieren?"
            )

def _install_zip(zip_path, source_label="Update"):
    if not os.path.isfile(zip_path):
        raise RuntimeError("Update-ZIP wurde nicht gefunden.")

    with zipfile.ZipFile(zip_path, "r") as zf:
        prefix, new_version, new_name = _zip_layout(zf)

        current = _current_info()
        old_version = current.get("version", "unbekannt")

        message = (
            "%s\n\n"
            "Installiert: %s\n"
            "Neue Version: %s\n\n"
            "Persönliche TopCop1000-Daten unter userdata/addon_data "
            "werden nicht gelöscht.\n\n"
            "Update jetzt installieren?"
        ) % (source_label, old_version, new_version)

        if not _dialog().yesno("TopCop1000 Installer", message):
            return False

        parent = os.path.dirname(ADDON_DIR.rstrip("/\\"))
        work_dir = tempfile.mkdtemp(prefix="topcop_install_", dir=parent)

        try:
            staged = os.path.join(work_dir, ADDON_ID)
            _safe_extract_plugin(zf, prefix, staged)

            staged_id, staged_version, staged_name = _addon_xml_info(
                os.path.join(staged, "addon.xml")
            )
            if staged_id != ADDON_ID:
                raise RuntimeError("Prüfung des entpackten Add-ons fehlgeschlagen.")

            if not _dependency_gate_staged(staged, "%s %s" % (staged_name, staged_version)):
                return False

            # Vor dem Austausch vollständige Code-Sicherung.
            backup_path = _backup_current()

            old_dir = None
            try:
                if os.path.isdir(ADDON_DIR):
                    old_dir = ADDON_DIR.rstrip("/\\") + ".installer_old"
                    if os.path.exists(old_dir):
                        shutil.rmtree(old_dir, ignore_errors=True)
                    os.replace(ADDON_DIR.rstrip("/\\"), old_dir)

                os.replace(staged, ADDON_DIR.rstrip("/\\"))

                # Neue Installation nochmals prüfen.
                installed_id, installed_version, _ = _addon_xml_info(
                    os.path.join(ADDON_DIR, "addon.xml")
                )
                if installed_id != ADDON_ID:
                    raise RuntimeError("Installierte Add-on-ID stimmt nicht.")

                if old_dir and os.path.isdir(old_dir):
                    shutil.rmtree(old_dir, ignore_errors=True)

            except Exception:
                # Sofortige Rückkehr zur vorherigen Ordnerfassung, falls der Austausch scheitert.
                try:
                    if os.path.isdir(ADDON_DIR):
                        shutil.rmtree(ADDON_DIR, ignore_errors=True)
                    if old_dir and os.path.isdir(old_dir):
                        os.replace(old_dir, ADDON_DIR.rstrip("/\\"))
                except Exception:
                    pass
                raise

            backup_note = (
                "\n\nSicherung angelegt:\n%s" % os.path.basename(backup_path)
                if backup_path else ""
            )

            _dialog().ok(
                "TopCop1000 Installer",
                "Update erfolgreich.\n\n"
                "Version: %s%s\n\n"
                "Kodi bitte einmal komplett neu starten."
                % (installed_version, backup_note)
            )
            return True

        finally:
            shutil.rmtree(work_dir, ignore_errors=True)


def _install_from_url():
    cfg = _load_config()
    url = _safe_text(cfg.get("update_url"))

    if not url:
        _dialog().ok(
            "TopCop1000 Installer",
            "Es ist noch keine Update-Adresse gespeichert.\n\n"
            "Bitte zuerst 'Update-Adresse festlegen' verwenden."
        )
        return

    _mkdirs()
    temp_zip = os.path.join(PROFILE_DIR, "TopCop1000_download.tmp.zip")

    try:
        _notify("Update wird heruntergeladen …", 2500)
        _download(url, temp_zip)
        _install_zip(temp_zip, "Online-Update")
    except Exception as exc:
        _dialog().ok(
            "TopCop1000 Installer",
            "Update fehlgeschlagen:\n%s" % exc
        )
    finally:
        try:
            if os.path.isfile(temp_zip):
                os.remove(temp_zip)
        except Exception:
            pass


def _install_local_zip():
    try:
        path = _dialog().browseSingle(
            1,
            "TopCop1000 Update-ZIP auswählen",
            "files",
            ".zip"
        )
        path = _safe_text(path)
        if not path:
            return

        # Kodi-Pfade wie special:// / smb:// etc. zunächst lokal auflösen/kopieren.
        local_path = xbmcvfs.translatePath(path)

        if not os.path.isfile(local_path):
            # Fallback über xbmcvfs in eine lokale Temp-Datei.
            _mkdirs()
            temp_zip = os.path.join(PROFILE_DIR, "TopCop1000_local.tmp.zip")
            with xbmcvfs.File(path, "rb") as src:
                data = src.readBytes()
            with open(temp_zip, "wb") as dst:
                dst.write(data)
            local_path = temp_zip
        else:
            temp_zip = None

        try:
            _install_zip(local_path, "Lokales ZIP-Update")
        finally:
            if temp_zip and os.path.isfile(temp_zip):
                os.remove(temp_zip)

    except Exception as exc:
        _dialog().ok(
            "TopCop1000 Installer",
            "Lokales Update fehlgeschlagen:\n%s" % exc
        )


def _backup_list():
    _mkdirs()
    items = []
    for name in os.listdir(BACKUP_DIR):
        if name.lower().endswith(".zip"):
            full = os.path.join(BACKUP_DIR, name)
            if os.path.isfile(full):
                items.append((os.path.getmtime(full), name, full))
    items.sort(reverse=True)
    return items


def _restore_backup():
    backups = _backup_list()
    if not backups:
        _dialog().ok(
            "TopCop1000 Installer",
            "Es wurde noch keine Installer-Sicherung gefunden."
        )
        return

    labels = [name for _, name, _ in backups]
    pos = _dialog().select(
        "Welche TopCop1000-Sicherung wiederherstellen?",
        labels
    )
    if pos < 0:
        return

    _, name, path = backups[pos]

    if not _dialog().yesno(
        "TopCop1000 Installer",
        "Diese Sicherung wiederherstellen?\n\n%s\n\n"
        "Die aktuellen Add-on-Dateien werden vorher nochmals gesichert."
        % name
    ):
        return

    parent = os.path.dirname(ADDON_DIR.rstrip("/\\"))
    work_dir = tempfile.mkdtemp(prefix="topcop_restore_", dir=parent)

    try:
        staged = os.path.join(work_dir, ADDON_ID)
        os.makedirs(staged, exist_ok=True)

        with zipfile.ZipFile(path, "r") as zf:
            # Backup-ZIPs enthalten Dateien relativ zum Plugin-Hauptordner.
            _safe_extract_plugin(zf, "", staged)

        staged_id, staged_version, _ = _addon_xml_info(
            os.path.join(staged, "addon.xml")
        )
        if staged_id != ADDON_ID:
            raise RuntimeError("Die gewählte Sicherung gehört nicht zu TopCop1000.")

        safety_backup = _backup_current()

        old_dir = None
        try:
            if os.path.isdir(ADDON_DIR):
                old_dir = ADDON_DIR.rstrip("/\\") + ".installer_old"
                if os.path.exists(old_dir):
                    shutil.rmtree(old_dir, ignore_errors=True)
                os.replace(ADDON_DIR.rstrip("/\\"), old_dir)

            os.replace(staged, ADDON_DIR.rstrip("/\\"))

            if old_dir and os.path.isdir(old_dir):
                shutil.rmtree(old_dir, ignore_errors=True)

        except Exception:
            try:
                if os.path.isdir(ADDON_DIR):
                    shutil.rmtree(ADDON_DIR, ignore_errors=True)
                if old_dir and os.path.isdir(old_dir):
                    os.replace(old_dir, ADDON_DIR.rstrip("/\\"))
            except Exception:
                pass
            raise

        _dialog().ok(
            "TopCop1000 Installer",
            "Wiederherstellung erfolgreich.\n\n"
            "Version: %s\n\n"
            "Kodi bitte einmal komplett neu starten."
            % staged_version
        )

    except Exception as exc:
        _dialog().ok(
            "TopCop1000 Installer",
            "Wiederherstellung fehlgeschlagen:\n%s" % exc
        )
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


def _show_status():
    info = _current_info()
    cfg = _load_config()
    url = _safe_text(cfg.get("update_url"))
    backups = _backup_list()

    lines = [
        "Installiert: %s" % ("JA" if info.get("installed") else "NEIN"),
        "Version: %s" % info.get("version", "unbekannt"),
        "Add-on-Pfad: %s" % ADDON_DIR,
        "",
        "Update-Adresse:",
        url if url else "noch nicht festgelegt",
        "",
        "Installer-Sicherungen: %d" % len(backups),
        "Python-Paketordner: %s" % package_dir(),
        "Persönliche Daten werden bei Updates nicht gelöscht.",
    ]

    _dialog().ok("TopCop1000 Installer - Status", "\n".join(lines))


def main(context=None):
    _mkdirs()

    choices = [
        "Neueste Version online installieren",
        "Update aus lokaler ZIP installieren",
        "Update-Adresse festlegen / ändern",
        "Vorherige Version wiederherstellen",
        "Status anzeigen",
        "Beenden",
    ]

    while True:
        pos = _dialog().select("TopCop1000 Installer", choices)

        if pos < 0 or pos == 5:
            return "Installer beendet"
        if pos == 0:
            _install_from_url()
        elif pos == 1:
            _install_local_zip()
        elif pos == 2:
            _set_update_url()
        elif pos == 3:
            _restore_backup()
        elif pos == 4:
            _show_status()


if __name__ == "__main__":
    main({})
