# -*- coding: utf-8 -*-
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

import xbmc
import xbmcvfs
import os
import shutil



def ensure_permanent_installer():
    """Hält den permanenten Installer zusätzlich im Python-Portal aktuell."""
    try:
        addon_root = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.topcop1000/"
        )
        packaged = os.path.join(
            addon_root, "resources", "tools", "TopCop1000_Installer.py"
        )
        modules_dir = xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.topcop1000/modules/"
        )
        os.makedirs(modules_dir, exist_ok=True)
        target = os.path.join(modules_dir, "TopCop1000_Installer.py")

        if not os.path.isfile(packaged):
            xbmc.log(
                "TopCop1000: permanenter Installer fehlt im Add-on.",
                xbmc.LOGWARNING
            )
            return

        copy_needed = True
        if os.path.isfile(target):
            try:
                with open(packaged, "rb") as src:
                    new_data = src.read()
                with open(target, "rb") as dst:
                    old_data = dst.read()
                copy_needed = new_data != old_data
            except Exception:
                copy_needed = True

        if copy_needed:
            tmp = target + ".tmp"
            shutil.copyfile(packaged, tmp)
            os.replace(tmp, target)
            xbmc.log(
                "TopCop1000: permanenter Installer im Python-Portal aktualisiert.",
                xbmc.LOGINFO
            )
    except Exception as exc:
        xbmc.log(
            "TopCop1000: Installer-Bereitstellung fehlgeschlagen: %s" % exc,
            xbmc.LOGERROR
        )

ensure_permanent_installer()

PORT = 8765
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.topcop1000/")
if not xbmcvfs.exists(DATA_DIR):
    xbmcvfs.mkdirs(DATA_DIR)
INBOX = DATA_DIR.rstrip("/\\") + "/phone_paste.txt"

PAGE = """<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TopCop1000</title>
<style>
body{font-family:sans-serif;background:#10131a;color:#fff;max-width:700px;margin:30px auto;padding:20px}
h1{font-size:28px} textarea{width:100%;height:180px;box-sizing:border-box;font-size:18px;padding:12px;border-radius:10px}
button{width:100%;margin-top:14px;padding:15px;font-size:20px;font-weight:bold;border:0;border-radius:10px}
p{line-height:1.5}.ok{padding:12px;border:1px solid #6f6;border-radius:10px;margin-bottom:14px}.err{padding:12px;border:1px solid #f66;border-radius:10px;margin-bottom:14px}
</style></head>
<body><h1>TopCop1000</h1><p>Text, URL oder Zugangswert hier einfuegen und an Kodi senden.</p>
__MESSAGE__
<form method="post" action="/" accept-charset="UTF-8"><textarea name="value" autofocus placeholder="Hier einfuegen ..."></textarea><button type="submit">AN KODI SENDEN</button></form>
<p>Nur im eigenen/vertrauten WLAN verwenden.</p></body></html>"""


def write_inbox(value):
    # Use the real translated filesystem path. This is more reliable on Android/Fire TV
    # than sharing an xbmcvfs.File handle between Kodi's service and plugin processes.
    path = xbmcvfs.translatePath(INBOX)
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(value)
        f.flush()
        try:
            os.fsync(f.fileno())
        except Exception:
            pass
    os.replace(tmp, path)
    xbmc.log("TopCop1000 phone paste saved to %s (%d chars)" % (path, len(value)), xbmc.LOGINFO)


class Handler(BaseHTTPRequestHandler):
    def _send(self, message=""):
        body = PAGE.replace("__MESSAGE__", message).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send()

    def do_POST(self):
        try:
            length = min(int(self.headers.get("Content-Length", "0") or "0"), 65536)
            raw = self.rfile.read(length).decode("utf-8", "replace")
            value = parse_qs(raw, keep_blank_values=True).get("value", [""])[0].strip()
            if not value:
                self._send('<div class="err">Kein Text eingegeben.</div>')
                return
            write_inbox(value)
            if not os.path.exists(xbmcvfs.translatePath(INBOX)):
                raise IOError("inbox not created")
            self._send('<div class="ok">GESENDET. Der Text liegt jetzt fuer Kodi bereit. Waehle dort „Vom Handy uebernehmen“.</div>')
        except Exception as exc:
            xbmc.log("TopCop1000 phone paste POST failed: %s" % exc, xbmc.LOGERROR)
            self._send('<div class="err">Senden fehlgeschlagen. Bitte Kodi neu starten und erneut versuchen.</div>')

    def log_message(self, fmt, *args):
        pass


monitor = xbmc.Monitor()
server = None
try:
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    server.timeout = 1
    xbmc.log("TopCop1000 phone paste server listening on port %d" % PORT, xbmc.LOGINFO)
    while not monitor.abortRequested():
        server.handle_request()
finally:
    if server:
        server.server_close()
