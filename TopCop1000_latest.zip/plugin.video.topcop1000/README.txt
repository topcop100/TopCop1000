TopCop1000 0.9.17.0

Aktueller installierbarer Meilenstein vom 06.09.2026.

Enthalten:
- Portal-Center
- M3U / M3U8
- Stalker / Ministra
- Xtream Codes
- Enigma2
- Plex
- Python-Portal
- Eigene Dateien
- scan4all
- Handy Copy & Paste
- Portal-Checker / Quellenverwaltung
- ZIP-Manager:
  * Ordner als ZIP packen
  * ZIP entpacken
  * ZIP-Inhalt anzeigen
  * TopCop1000-Plugin komplett als ZIP sichern

Bestätigt:
- M3U-Quelle "deutschland" erreichbar (HTTP 200)
- Live-TV-Wiedergabe funktioniert
- Xtream-, Enigma2- und Plex-Oberflächen sind eingebaut
- Stalker/Ministra-Funktionen waren bereits vorhanden
- ZIP-Manager wurde auf der KodiBox erfolgreich getestet

Noch mit echten, autorisierten Zugangsdaten zu testen:
- Stalker / Ministra
- Xtream Codes
- Enigma2
- Plex

Wichtig:
Gespeicherte Quellen und persönliche TopCop1000-Daten liegen unter
special://profile/addon_data/plugin.video.topcop1000/
und sind NICHT Bestandteil dieser Installations-ZIP.
Ein normales Add-on-Update überschreibt diese Daten daher nicht.

Nur eigene bzw. autorisierte Quellen und Zugänge verwenden.


Neu in 0.9.18.0:
- Permanenter Installer / Updater ist fest in TopCop1000 enthalten.
- Neuer Hauptmenüpunkt: Installer / Updater.
- Zusätzlich wird der Installer beim Kodi-Start automatisch im Python-Portal bereitgestellt.
- Lokale Update-ZIPs können direkt über den Installer installiert werden.
- Vor Updates kann die aktuelle Add-on-Version automatisch gesichert werden.
- Eine frühere Installer-Sicherung kann wiederhergestellt werden.
- Persönliche Quellen unter userdata/addon_data bleiben getrennt vom Add-on-Code.

Version 0.9.19.0 - PY-/Paket-Installer
--------------------------------------
- PY-Dateien werden vor dem Hinzufügen statisch auf Imports/Abhängigkeiten geprüft.
- Fehlende, bekannte reine Python-Module können in einen TopCop1000-eigenen Paketordner installiert werden.
- Binärpakete, native Wheels und Quellcode-Builds werden automatisch abgelehnt.
- Bei nicht auflösbaren Abhängigkeiten gibt es Details, Abbrechen und „Trotzdem ... auf eigenes Risiko“ mit zweiter Warnung.
- Manueller PyPI-Paketname kann eingegeben werden; auch hier werden nur reine Universal-Wheels akzeptiert.
- Kontrollierte PY-Pakete aus ZIP werden unterstützt (main.py oder topcop-package.json).
- Installationsprotokoll im Python-Portal.
- Der permanente TopCop1000 Installer prüft künftig Python-Abhängigkeiten vor dem Code-Austausch.
