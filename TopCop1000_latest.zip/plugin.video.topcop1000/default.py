# -*- coding: utf-8 -*-
import os
import re
import sys
import importlib.util
import time
import json
import zipfile
import shutil
import tempfile
import base64
import xml.etree.ElementTree as ET
from urllib.parse import parse_qsl, urlencode, quote, urlsplit, urlunsplit
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.settings_store import load_settings, save_settings
from resources.lib.m3u_scanner import load_m3u, group_entries
from resources.lib.portal_registry import get_portal_types
from resources.lib.output_store import list_outputs, output_root
from resources.lib.portal_checker import check_entry, status_label
from resources.lib.portal_status import inspect_entry, find_duplicates, compact_line
from resources.lib.stalker_client import get_genres as stalker_get_genres, get_channels as stalker_get_channels, create_link as stalker_create_link, get_profile as stalker_get_profile, StalkerError
from resources.lib.python_package_installer import (
    analyze_python_file, analyze_python_tree, ensure_package_path, format_report,
    install_missing_modules, manual_install, prepare_python_zip, read_log,
    report_ok, script_packages_dir,
)

HANDLE = int(sys.argv[1])
ensure_package_path()

def params():
    return dict(parse_qsl(sys.argv[2].lstrip("?"))) if len(sys.argv) >= 3 else {}

def plugin_url(action, **kwargs):
    q = {"action": action}
    q.update(kwargs)
    return sys.argv[0] + "?" + urlencode(q)

def add_dir(label, action, **kwargs):
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action, **kwargs), li, True)

def add_item(label, action="", folder=False, **kwargs):
    li = xbmcgui.ListItem(label=label)
    url = plugin_url(action, **kwargs) if action else ""
    xbmcplugin.addDirectoryItem(HANDLE, url, li, folder)

def add_stream(label, url, icon=""):
    li = xbmcgui.ListItem(label=label)
    if icon:
        li.setArt({"icon": icon, "thumb": icon})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, url, li, False)

def root():
    add_dir("Portal-Center", "portal_center")
    add_dir("Live TV", "m3u_section", section="tv")
    add_dir("Filme", "m3u_section", section="movies")
    add_dir("Serien", "m3u_section", section="series")
    add_dir("Python-Portal", "python_center")
    add_dir("Eigene Dateien", "own_files")
    add_dir("ZIP-Manager", "zip_manager")
    add_item("Installer / Updater", "permanent_installer")
    add_dir("scan4all", "scan4all_archive")
    xbmcplugin.endOfDirectory(HANDLE)

def portal_center():
    add_dir("Handy Copy & Paste", "phone_paste_info")
    add_dir("Portal-Übersicht", "portal_overview")
    add_dir("Alle Portale prüfen", "check_all")
    for p in get_portal_types():
        add_dir(p["label"], "portal_type", portal_type=p["id"])
    add_dir("Alle gespeicherten Quellen", "saved_sources")
    add_dir("Ausgaben", "outputs")
    xbmcplugin.endOfDirectory(HANDLE)

def _phone_inbox_path():
    folder = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.topcop1000/")
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    return folder.rstrip("/\\") + "/phone_paste.txt"

def _phone_paste_get():
    path = xbmcvfs.translatePath(_phone_inbox_path())
    try:
        # The HTTP service writes atomically. A tiny retry also covers the moment
        # immediately after the phone reports that the POST completed.
        for _ in range(4):
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as fh:
                    value = fh.read().strip()
                if value:
                    # Keep the last phone value available. This prevents an accidental
                    # field selection from destroying it; the next phone send overwrites it.
                    xbmc.log("TopCop1000 phone paste read from %s (%d chars)" % (path, len(value)), xbmc.LOGINFO)
                    return value
            time.sleep(0.15)
        return ""
    except Exception as exc:
        xbmc.log("TopCop1000 phone paste read failed: %s" % exc, xbmc.LOGERROR)
        return ""

def phone_paste_info():
    ip = xbmc.getIPAddress() or "IP-DES-FIRE-TV"
    url = "http://%s:8765" % ip
    xbmcgui.Dialog().ok("TopCop1000 - Handy Copy & Paste",
        "Handy und Fire TV muessen im gleichen WLAN sein.\n\n"
        "1. Oeffne am Handy im Browser:\n%s\n\n"
        "2. Text einfuegen und auf SENDEN tippen.\n"
        "3. Danach im Eingabefeld 'Vom Handy uebernehmen' waehlen.\n\n"
        "Nur im eigenen/vertrauten Heimnetz verwenden." % url)
    xbmcplugin.endOfDirectory(HANDLE)

def _clipboard_get():
    # Best effort: Kodi has no cross-platform clipboard API. Try platform helpers.
    try:
        from jnius import autoclass
        PythonActivity = autoclass("org.kodi.kodi.Main")
        activity = PythonActivity.getActivity()
        Context = autoclass("android.content.Context")
        cm = activity.getSystemService(Context.CLIPBOARD_SERVICE)
        clip = cm.getPrimaryClip()
        if clip and clip.getItemCount() > 0:
            text = clip.getItemAt(0).coerceToText(activity)
            if text is not None:
                return str(text)
    except Exception:
        pass
    try:
        import subprocess
        if xbmc.getCondVisibility("System.Platform.OSX"):
            return subprocess.check_output(["pbpaste"]).decode("utf-8", "replace")
    except Exception:
        pass
    return ""

def _clipboard_set(text):
    text = str(text or "")
    try:
        from jnius import autoclass
        PythonActivity = autoclass("org.kodi.kodi.Main")
        activity = PythonActivity.getActivity()
        Context = autoclass("android.content.Context")
        ClipData = autoclass("android.content.ClipData")
        cm = activity.getSystemService(Context.CLIPBOARD_SERVICE)
        cm.setPrimaryClip(ClipData.newPlainText("TopCop1000", text))
        return True
    except Exception:
        pass
    try:
        import subprocess
        if xbmc.getCondVisibility("System.Platform.OSX"):
            proc = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-8"))
            return proc.returncode == 0
    except Exception:
        pass
    return False

def _ask_text(title, default="", hidden=False):
    dlg = xbmcgui.Dialog()
    # On portal fields offer a simple Copy/Paste style choice before opening Kodi's keyboard.
    choice = dlg.select(title, ["Eingeben / bearbeiten", "Vom Handy uebernehmen", "Aus Zwischenablage einfuegen"])
    if choice < 0:
        return ""
    if choice == 1:
        pasted = _phone_paste_get()
        if pasted:
            return pasted
        dlg.ok("TopCop1000", "Noch kein Text vom Handy empfangen.\n\nOeffne zuerst 'Handy Copy & Paste' im Portal-Center und sende den Text dort ab.")
        return ""
    if choice == 2:
        pasted = (_clipboard_get() or "").strip()
        if pasted:
            return pasted
        dlg.notification("TopCop1000", "Zwischenablage nicht verfuegbar - Tastatur wird geoeffnet.", time=3000)
    option = xbmcgui.ALPHANUM_HIDE_INPUT if hidden else 0
    value = dlg.input(title, defaultt=str(default or ""), type=xbmcgui.INPUT_ALPHANUM, option=option)
    return (value or "").strip()

def add_source(portal_type):
    cfg = load_settings()
    sources = cfg.setdefault("sources", {})
    entries = sources.setdefault(portal_type, [])
    name = _ask_text("TopCop1000 - Name der Quelle")
    if not name:
        xbmcgui.Dialog().notification("TopCop1000", "Abgebrochen: kein Name eingegeben.", time=2500)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    entry = {"name": name}
    if portal_type == "stalker":
        entry["url"] = _ask_text("Stalker / Ministra - Portal-URL", "http://")
        if not entry["url"]:
            xbmcgui.Dialog().notification("TopCop1000", "Abgebrochen: keine URL eingegeben.", time=2500)
            xbmcplugin.endOfDirectory(HANDLE); return
        entry["mac"] = _ask_text("MAC-Adresse (eigener/autorisierter Zugang)")
    elif portal_type == "xtream":
        entry["url"] = _ask_text("Xtream - Server-URL", "http://")
        if not entry["url"]:
            xbmcgui.Dialog().notification("TopCop1000", "Abgebrochen: keine URL eingegeben.", time=2500)
            xbmcplugin.endOfDirectory(HANDLE); return
        entry["username"] = _ask_text("Xtream - Benutzername")
        entry["password"] = _ask_text("Xtream - Passwort", hidden=True)
    elif portal_type == "m3u":
        entry["url"] = _ask_text("M3U / M3U8 - URL")
        if not entry["url"]:
            xbmcgui.Dialog().notification("TopCop1000", "Abgebrochen: keine URL eingegeben.", time=2500)
            xbmcplugin.endOfDirectory(HANDLE); return
    elif portal_type == "enigma2":
        entry["url"] = _ask_text("Enigma2 - Server-URL", "http://")
        if not entry["url"]:
            xbmcgui.Dialog().notification("TopCop1000", "Abgebrochen: keine URL eingegeben.", time=2500)
            xbmcplugin.endOfDirectory(HANDLE); return
        entry["username"] = _ask_text("Enigma2 - Benutzername (optional)")
        entry["password"] = _ask_text("Enigma2 - Passwort (optional)", hidden=True)
    elif portal_type == "plex":
        entry["url"] = _ask_text("Plex - Server-URL", "http://")
        if not entry["url"]:
            xbmcgui.Dialog().notification("TopCop1000", "Abgebrochen: keine URL eingegeben.", time=2500)
            xbmcplugin.endOfDirectory(HANDLE); return
        entry["token"] = _ask_text("Plex - Token (optional)", hidden=True)
    else:
        xbmcgui.Dialog().ok("TopCop1000", "Dieser Quellentyp kann hier nicht angelegt werden.")
        xbmcplugin.endOfDirectory(HANDLE); return
    entries.append(entry)
    save_settings(cfg)
    xbmcgui.Dialog().notification("TopCop1000", "%s wurde gespeichert." % name, time=3000)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE)

def portal_type(portal_type):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get(portal_type, [])
    if portal_type != "python":
        add_item("+ Portal / Quelle hinzufügen", "add_source", portal_type=portal_type)
    if not entries:
        add_item("Noch keine Quelle hinterlegt")
    for idx, entry in enumerate(entries):
        name = entry.get("name") or f"{portal_type} {idx+1}"
        add_dir("> " + name, "source_open", portal_type=portal_type, index=str(idx))
        add_item("   Prüfen: " + name, "check_one", portal_type=portal_type, index=str(idx))
    xbmcplugin.endOfDirectory(HANDLE)

def portal_overview():
    cfg = load_settings()
    sources = cfg.get("sources", {})
    dupes = find_duplicates(sources)
    labels = {x["id"]: x["label"] for x in get_portal_types()}
    total = 0
    for typ, entries in sources.items():
        if typ == "python":
            continue
        for idx, entry in enumerate(entries):
            total += 1
            name = entry.get("name") or ("Quelle %d" % (idx + 1))
            info = inspect_entry(typ, entry)
            detail = compact_line(info, duplicate=(typ, idx) in dupes)
            add_dir("%s → %s" % (labels.get(typ, typ), name), "source_open", portal_type=typ, index=str(idx))
            add_item("   " + detail)
            add_item("   %s • TopCop1000" % typ.upper())
    if total == 0:
        add_item("Keine gespeicherten Portale vorhanden")
    xbmcplugin.endOfDirectory(HANDLE)

def check_one(portal_type, index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get(portal_type, [])
    try:
        entry = entries[int(index)]
    except Exception:
        xbmcgui.Dialog().ok("TopCop1000", "Eintrag nicht gefunden.")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    name = entry.get("name") or "Quelle"
    result = check_entry(portal_type, entry)
    xbmcgui.Dialog().ok("TopCop1000 Portal-Checker", name + "\n\n" + status_label(result))
    xbmcplugin.endOfDirectory(HANDLE)

def check_all():
    cfg = load_settings()
    labels = {x["id"]: x["label"] for x in get_portal_types()}
    count = 0
    for typ, entries in cfg.get("sources", {}).items():
        if typ == "python":
            continue
        for idx, entry in enumerate(entries):
            count += 1
            name = entry.get("name") or f"Quelle {idx+1}"
            result = check_entry(typ, entry)
            add_item("%s · %s · %s" % (
                labels.get(typ, typ),
                name,
                status_label(result)
            ))
    if count == 0:
        add_item("Keine gespeicherten Portale vorhanden")
    xbmcplugin.endOfDirectory(HANDLE)



def edit_source(portal_type, index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get(portal_type, [])
    try:
        idx = int(index)
        entry = entries[idx]
    except Exception:
        xbmcgui.Dialog().ok("TopCop1000", "Eintrag nicht gefunden.")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    name = _ask_text("TopCop1000 - Name der Quelle", entry.get("name", ""))
    if name:
        entry["name"] = name

    if portal_type == "stalker":
        value = _ask_text("Stalker / Ministra - Portal-URL", entry.get("url", ""))
        if value:
            entry["url"] = value
        value = _ask_text("MAC-Adresse (leer = unverändert)")
        if value:
            entry["mac"] = value
    elif portal_type == "xtream":
        value = _ask_text("Xtream - Server-URL", entry.get("url", ""))
        if value:
            entry["url"] = value
        value = _ask_text("Xtream - Benutzername", entry.get("username", ""))
        if value:
            entry["username"] = value
        value = _ask_text("Xtream - neues Passwort (leer = unverändert)", hidden=True)
        if value:
            entry["password"] = value
    elif portal_type == "m3u":
        value = _ask_text("M3U / M3U8 - URL", entry.get("url", ""))
        if value:
            entry["url"] = value
    elif portal_type == "enigma2":
        value = _ask_text("Enigma2 - Server-URL", entry.get("url", ""))
        if value:
            entry["url"] = value
        value = _ask_text("Enigma2 - Benutzername (leer = unverändert)", entry.get("username", ""))
        if value:
            entry["username"] = value
        value = _ask_text("Enigma2 - neues Passwort (leer = unverändert)", hidden=True)
        if value:
            entry["password"] = value
    elif portal_type == "plex":
        value = _ask_text("Plex - Server-URL", entry.get("url", ""))
        if value:
            entry["url"] = value
        value = _ask_text("Plex - neuer Token (leer = unverändert)", hidden=True)
        if value:
            entry["token"] = value

    save_settings(cfg)
    xbmcgui.Dialog().notification("TopCop1000", "Quelle wurde aktualisiert.", time=2500)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE)

def delete_source(portal_type, index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get(portal_type, [])
    try:
        idx = int(index)
        entry = entries[idx]
    except Exception:
        xbmcgui.Dialog().ok("TopCop1000", "Eintrag nicht gefunden.")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    name = entry.get("name") or "Quelle"
    if not xbmcgui.Dialog().yesno("TopCop1000", "'%s' wirklich löschen?" % name):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    del entries[idx]
    save_settings(cfg)
    xbmcgui.Dialog().notification("TopCop1000", "%s wurde gelöscht." % name, time=2500)
    xbmc.executebuiltin("Action(ParentDir)")
    xbmcplugin.endOfDirectory(HANDLE)

def copy_source(portal_type, index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get(portal_type, [])
    try:
        entry = entries[int(index)]
    except Exception:
        xbmcgui.Dialog().ok("TopCop1000", "Eintrag nicht gefunden.")
        xbmcplugin.endOfDirectory(HANDLE); return
    fields = []
    for key, label in (("url", "URL"), ("mac", "MAC-Adresse"), ("username", "Benutzername"), ("password", "Passwort"), ("token", "Token")):
        if entry.get(key): fields.append((key, label))
    if not fields:
        xbmcgui.Dialog().notification("TopCop1000", "Kein kopierbarer Wert vorhanden.", time=2500)
        xbmcplugin.endOfDirectory(HANDLE); return
    pos = xbmcgui.Dialog().select("Welchen Wert kopieren?", [x[1] for x in fields])
    if pos >= 0:
        key, label = fields[pos]
        if _clipboard_set(entry.get(key, "")):
            xbmcgui.Dialog().notification("TopCop1000", label + " kopiert.", time=2500)
        else:
            xbmcgui.Dialog().ok("TopCop1000", "Kodi kann auf diesem Geraet die Zwischenablage nicht direkt beschreiben.")
    xbmcplugin.endOfDirectory(HANDLE)



def _xtream_entry(index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get("xtream", [])
    try:
        return entries[int(index)]
    except Exception:
        raise RuntimeError("Xtream-Eintrag nicht gefunden.")


def _xtream_base_url(entry):
    return str(entry.get("url") or "").strip().rstrip("/")


def _xtream_api(entry, action=None, **kwargs):
    base = _xtream_base_url(entry)
    username = str(entry.get("username") or "").strip()
    password = str(entry.get("password") or "").strip()

    if not base or not username or not password:
        raise RuntimeError("Server-URL, Benutzername oder Passwort fehlt.")

    params = {"username": username, "password": password}
    if action:
        params["action"] = action
    params.update(kwargs)

    api_url = base + "/player_api.php?" + urlencode(params)
    req = Request(api_url, headers={"User-Agent": "TopCop1000/1.0"})

    try:
        with urlopen(req, timeout=12) as resp:
            raw = resp.read()
    except Exception as exc:
        raise RuntimeError("Xtream-Server nicht erreichbar: %s" % exc)

    try:
        return json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        raise RuntimeError("Xtream-Server lieferte keine gültige JSON-Antwort.")


def xtream_test(index):
    try:
        entry = _xtream_entry(index)
        data = _xtream_api(entry)
        user_info = data.get("user_info") if isinstance(data, dict) else None

        if not isinstance(user_info, dict):
            raise RuntimeError("Keine Benutzerinformationen erhalten.")

        auth = str(user_info.get("auth") or "")
        status = str(user_info.get("status") or "")
        if auth != "1" and status.lower() not in ("active", "aktiv"):
            raise RuntimeError("Xtream-Anmeldung wurde abgelehnt.")

        active_conn = str(user_info.get("active_cons") or "n/v")
        max_conn = str(user_info.get("max_connections") or "n/v")
        exp = str(user_info.get("exp_date") or "n/v")

        xbmcgui.Dialog().ok(
            "TopCop1000 – Xtream",
            "Anmeldung erfolgreich.\n\n"
            "Status: %s\n"
            "Aktive Verbindungen: %s\n"
            "Max. Verbindungen: %s\n"
            "Ablauf: %s" % (status or "OK", active_conn, max_conn, exp)
        )
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Xtream",
            "Anmeldung fehlgeschlagen:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)


def _xtream_section_meta(section):
    if section == "live":
        return "get_live_categories", "get_live_streams"
    if section == "vod":
        return "get_vod_categories", "get_vod_streams"
    if section == "series":
        return "get_series_categories", "get_series"
    raise RuntimeError("Unbekannter Xtream-Bereich.")


def xtream_categories(index, section):
    try:
        entry = _xtream_entry(index)
        category_action, _ = _xtream_section_meta(section)
        categories = _xtream_api(entry, category_action)

        if not isinstance(categories, list):
            raise RuntimeError("Keine Kategorien erhalten.")

        add_dir(
            "Alle",
            "xtream_items",
            index=str(index),
            section=section,
            category="__all__"
        )

        count = 0
        for category in categories:
            if not isinstance(category, dict):
                continue

            category_id = str(category.get("category_id") or "").strip()
            name = str(
                category.get("category_name")
                or category.get("name")
                or ""
            ).strip()

            if category_id and name:
                add_dir(
                    name,
                    "xtream_items",
                    index=str(index),
                    section=section,
                    category=category_id
                )
                count += 1

        if count == 0:
            add_item("Keine Kategorien gemeldet – 'Alle' verwenden")

    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Xtream",
            "Kategorien konnten nicht geladen werden:\n%s" % exc
        )

    xbmcplugin.endOfDirectory(HANDLE)


def _xtream_stream_url(entry, kind, stream_id, extension=""):
    base = _xtream_base_url(entry)
    username = str(entry.get("username") or "").strip()
    password = str(entry.get("password") or "").strip()
    stream_id = str(stream_id or "").strip()

    if not stream_id:
        return ""

    ext = str(extension or "").strip().lstrip(".")
    if kind == "live":
        return "%s/live/%s/%s/%s.%s" % (
            base, username, password, stream_id, ext or "ts"
        )
    if kind == "vod":
        return "%s/movie/%s/%s/%s.%s" % (
            base, username, password, stream_id, ext or "mp4"
        )
    if kind == "series":
        return "%s/series/%s/%s/%s.%s" % (
            base, username, password, stream_id, ext or "mp4"
        )
    return ""


def xtream_items(index, section, category):
    try:
        entry = _xtream_entry(index)
        _, list_action = _xtream_section_meta(section)

        kwargs = {}
        if category != "__all__":
            kwargs["category_id"] = category

        items = _xtream_api(entry, list_action, **kwargs)
        if not isinstance(items, list):
            raise RuntimeError("Keine Einträge erhalten.")

        count = 0
        for item in items:
            if not isinstance(item, dict):
                continue

            name = str(item.get("name") or item.get("title") or "Unbenannt")
            icon = str(
                item.get("stream_icon")
                or item.get("cover")
                or item.get("cover_big")
                or ""
            )

            if section == "live":
                stream_id = item.get("stream_id")
                if stream_id is None:
                    continue
                url = _xtream_stream_url(
                    entry,
                    "live",
                    stream_id,
                    item.get("container_extension") or "ts"
                )
                add_stream(name, url, icon)
                count += 1

            elif section == "vod":
                stream_id = item.get("stream_id")
                if stream_id is None:
                    continue
                url = _xtream_stream_url(
                    entry,
                    "vod",
                    stream_id,
                    item.get("container_extension") or "mp4"
                )
                add_stream(name, url, icon)
                count += 1

            elif section == "series":
                series_id = item.get("series_id")
                if series_id is None:
                    continue
                add_dir(
                    name,
                    "xtream_series_info",
                    index=str(index),
                    series_id=str(series_id)
                )
                count += 1

        if count == 0:
            add_item("Keine Einträge gefunden")

    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Xtream",
            "Inhalte konnten nicht geladen werden:\n%s" % exc
        )

    xbmcplugin.endOfDirectory(HANDLE)


def xtream_series_info(index, series_id):
    try:
        entry = _xtream_entry(index)
        data = _xtream_api(
            entry,
            "get_series_info",
            series_id=str(series_id)
        )

        episodes = data.get("episodes") if isinstance(data, dict) else None
        if not isinstance(episodes, dict):
            raise RuntimeError("Keine Episoden erhalten.")

        season_keys = []
        for key in episodes.keys():
            try:
                sort_key = int(key)
            except Exception:
                sort_key = 999999
            season_keys.append((sort_key, str(key)))
        season_keys.sort()

        count = 0
        for _, season_key in season_keys:
            season_episodes = episodes.get(season_key) or []
            if not isinstance(season_episodes, list):
                continue

            for episode in season_episodes:
                if not isinstance(episode, dict):
                    continue

                episode_id = episode.get("id")
                if episode_id is None:
                    continue

                episode_num = episode.get("episode_num")
                title = str(
                    episode.get("title")
                    or episode.get("name")
                    or ("Episode " + str(episode_num or ""))
                )

                label = "S%sE%s · %s" % (
                    season_key,
                    episode_num if episode_num is not None else "?",
                    title
                )
                url = _xtream_stream_url(
                    entry,
                    "series",
                    episode_id,
                    episode.get("container_extension") or "mp4"
                )
                add_stream(label, url)
                count += 1

        if count == 0:
            add_item("Keine Episoden gefunden")

    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Xtream",
            "Serie konnte nicht geladen werden:\n%s" % exc
        )

    xbmcplugin.endOfDirectory(HANDLE)



def _enigma2_entry(index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get("enigma2", [])
    try:
        return entries[int(index)]
    except Exception:
        raise RuntimeError("Enigma2-Eintrag nicht gefunden.")


def _enigma2_base_url(entry):
    base = str(entry.get("url") or "").strip().rstrip("/")
    if not base:
        raise RuntimeError("Enigma2-Server-URL fehlt.")
    return base


def _enigma2_auth_header(entry):
    username = str(entry.get("username") or "").strip()
    password = str(entry.get("password") or "")
    if not username:
        return ""
    token = ("%s:%s" % (username, password)).encode("utf-8")
    return "Basic " + base64.b64encode(token).decode("ascii")


def _enigma2_request(entry, path, params=None, timeout=12):
    base = _enigma2_base_url(entry)
    url = base + path
    if params:
        url += ("&" if "?" in url else "?") + urlencode(params)

    headers = {"User-Agent": "TopCop1000/1.0"}
    auth = _enigma2_auth_header(entry)
    if auth:
        headers["Authorization"] = auth

    req = Request(url, headers=headers)
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
    except Exception as exc:
        raise RuntimeError("Enigma2-Box nicht erreichbar: %s" % exc)

    try:
        return ET.fromstring(raw.decode("utf-8", "replace"))
    except Exception:
        raise RuntimeError("Enigma2 lieferte keine gültige XML-Antwort.")


def _enigma2_xml_text(root, *tags):
    for tag in tags:
        node = root.find(".//" + tag)
        if node is not None and node.text:
            value = str(node.text).strip()
            if value:
                return value
    return ""


def _enigma2_services_from_xml(root):
    result = []
    for service in root.findall(".//e2service"):
        ref = _enigma2_xml_text(service, "e2servicereference")
        name = _enigma2_xml_text(service, "e2servicename")
        if ref:
            result.append({"ref": ref, "name": name or ref})
    return result


def enigma2_test(index):
    try:
        entry = _enigma2_entry(index)
        root = _enigma2_request(entry, "/web/about")

        model = _enigma2_xml_text(root, "e2model", "e2boxname")
        image = _enigma2_xml_text(root, "e2imageversion", "e2enigmaversion")
        webif = _enigma2_xml_text(root, "e2webifversion")

        lines = ["Verbindung erfolgreich."]
        if model:
            lines.append("Box: %s" % model)
        if image:
            lines.append("Image/Enigma2: %s" % image)
        if webif:
            lines.append("OpenWebif: %s" % webif)

        xbmcgui.Dialog().ok("TopCop1000 – Enigma2", "\n".join(lines))
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Enigma2",
            "Verbindung fehlgeschlagen:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)


def enigma2_bouquets(index):
    try:
        entry = _enigma2_entry(index)
        root = _enigma2_request(entry, "/web/getservices")
        bouquets = _enigma2_services_from_xml(root)

        count = 0
        for bouquet in bouquets:
            ref = bouquet.get("ref") or ""
            name = bouquet.get("name") or "Bouquet"
            if not ref:
                continue
            add_dir(
                name,
                "enigma2_services",
                index=str(index),
                sref=ref
            )
            count += 1

        if count == 0:
            add_item("Keine TV-Bouquets gefunden")
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Enigma2",
            "Bouquets konnten nicht geladen werden:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)


def _enigma2_stream_url(entry, service_ref):
    base = _enigma2_base_url(entry)
    parts = urlsplit(base)

    username = str(entry.get("username") or "").strip()
    password = str(entry.get("password") or "")

    netloc = parts.netloc
    if username:
        host = parts.hostname or ""
        port = (":%s" % parts.port) if parts.port else ""
        netloc = "%s:%s@%s%s" % (
            quote(username, safe=""),
            quote(password, safe=""),
            host,
            port
        )

    base_with_auth = urlunsplit(
        (parts.scheme or "http", netloc, parts.path.rstrip("/"), "", "")
    )
    return (
        base_with_auth
        + "/web/stream.m3u?"
        + urlencode({"ref": service_ref})
    )


def enigma2_services(index, sref):
    try:
        entry = _enigma2_entry(index)
        root = _enigma2_request(
            entry,
            "/web/getservices",
            {"sRef": sref}
        )
        services = _enigma2_services_from_xml(root)

        count = 0
        for service in services:
            ref = service.get("ref") or ""
            name = service.get("name") or "Sender"

            # Skip common Enigma2 markers/separators.
            if not ref or ref.startswith("1:64:") or ref.startswith("1:832:"):
                continue

            add_stream(name, _enigma2_stream_url(entry, ref))
            count += 1

        if count == 0:
            add_item("Keine abspielbaren Sender gefunden")
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Enigma2",
            "Sender konnten nicht geladen werden:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)



def _plex_entry(index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get("plex", [])
    try:
        return entries[int(index)]
    except Exception:
        raise RuntimeError("Plex-Eintrag nicht gefunden.")


def _plex_base_url(entry):
    base = str(entry.get("url") or "").strip().rstrip("/")
    if not base:
        raise RuntimeError("Plex-Server-URL fehlt.")
    return base


def _plex_request(entry, path, params=None):
    base = _plex_base_url(entry)
    token = str(entry.get("token") or "").strip()

    query = dict(params or {})
    if token:
        query["X-Plex-Token"] = token

    url = base + path
    if query:
        url += ("&" if "?" in url else "?") + urlencode(query)

    headers = {
        "Accept": "application/xml",
        "X-Plex-Product": "TopCop1000",
        "X-Plex-Version": "1.0",
        "X-Plex-Client-Identifier": "TopCop1000-Kodi"
    }
    if token:
        headers["X-Plex-Token"] = token

    req = Request(url, headers=headers)
    try:
        with urlopen(req, timeout=12) as resp:
            raw = resp.read()
    except Exception as exc:
        raise RuntimeError("Plex-Server nicht erreichbar: %s" % exc)

    try:
        return ET.fromstring(raw)
    except Exception:
        raise RuntimeError("Plex-Server lieferte keine gültige XML-Antwort.")


def _plex_media_url(entry, path):
    base = _plex_base_url(entry)
    token = str(entry.get("token") or "").strip()
    if not path:
        return ""
    if str(path).startswith("http://") or str(path).startswith("https://"):
        url = str(path)
    else:
        url = base + str(path)
    if token:
        url += ("&" if "?" in url else "?") + urlencode({"X-Plex-Token": token})
    return url


def _plex_art_url(entry, path):
    return _plex_media_url(entry, path)


def plex_test(index):
    try:
        entry = _plex_entry(index)
        root = _plex_request(entry, "/identity")

        machine = str(root.attrib.get("machineIdentifier") or "n/v")
        version = str(root.attrib.get("version") or "n/v")

        xbmcgui.Dialog().ok(
            "TopCop1000 – Plex",
            "Verbindung erfolgreich.\n\n"
            "Plex-Version: %s\n"
            "Server-ID: %s" % (version, machine)
        )
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Plex",
            "Verbindung fehlgeschlagen:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)


def plex_sections(index, kind):
    try:
        entry = _plex_entry(index)
        root = _plex_request(entry, "/library/sections")

        count = 0
        for directory in root.findall(".//Directory"):
            section_type = str(directory.attrib.get("type") or "")
            if section_type != kind:
                continue

            key = str(directory.attrib.get("key") or "").strip()
            title = str(directory.attrib.get("title") or "Bibliothek")
            if not key:
                continue

            add_dir(
                title,
                "plex_section_items",
                index=str(index),
                section_key=key,
                kind=kind
            )
            count += 1

        if count == 0:
            if kind == "movie":
                add_item("Keine Film-Bibliothek gefunden")
            else:
                add_item("Keine Serien-Bibliothek gefunden")
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Plex",
            "Bibliotheken konnten nicht geladen werden:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)


def plex_section_items(index, section_key, kind):
    try:
        entry = _plex_entry(index)
        path = "/library/sections/%s/all" % quote(str(section_key), safe="")
        root = _plex_request(entry, path)

        count = 0
        if kind == "movie":
            nodes = root.findall(".//Video")
            for video in nodes:
                if str(video.attrib.get("type") or "") not in ("movie", ""):
                    continue
                rating_key = str(video.attrib.get("ratingKey") or "").strip()
                title = str(video.attrib.get("title") or "Film")
                year = str(video.attrib.get("year") or "").strip()
                label = ("%s (%s)" % (title, year)) if year else title
                thumb = _plex_art_url(entry, video.attrib.get("thumb") or "")

                if not rating_key:
                    continue

                li = xbmcgui.ListItem(label=label)
                if thumb:
                    li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb})
                li.setProperty("IsPlayable", "true")
                xbmcplugin.addDirectoryItem(
                    HANDLE,
                    plugin_url("plex_play", index=str(index), rating_key=rating_key),
                    li,
                    False
                )
                count += 1
        else:
            nodes = root.findall(".//Directory")
            for show in nodes:
                if str(show.attrib.get("type") or "") not in ("show", ""):
                    continue
                rating_key = str(show.attrib.get("ratingKey") or "").strip()
                title = str(show.attrib.get("title") or "Serie")
                year = str(show.attrib.get("year") or "").strip()
                label = ("%s (%s)" % (title, year)) if year else title

                if not rating_key:
                    continue

                add_dir(
                    label,
                    "plex_show_seasons",
                    index=str(index),
                    rating_key=rating_key
                )
                count += 1

        if count == 0:
            add_item("Keine Einträge gefunden")
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Plex",
            "Inhalte konnten nicht geladen werden:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)


def plex_show_seasons(index, rating_key):
    try:
        entry = _plex_entry(index)
        root = _plex_request(
            entry,
            "/library/metadata/%s/children" % quote(str(rating_key), safe="")
        )

        count = 0
        for season in root.findall(".//Directory"):
            if str(season.attrib.get("type") or "") not in ("season", ""):
                continue
            season_key = str(season.attrib.get("ratingKey") or "").strip()
            title = str(season.attrib.get("title") or "Staffel")
            if not season_key:
                continue

            add_dir(
                title,
                "plex_season_episodes",
                index=str(index),
                rating_key=season_key
            )
            count += 1

        if count == 0:
            add_item("Keine Staffeln gefunden")
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Plex",
            "Staffeln konnten nicht geladen werden:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)


def plex_season_episodes(index, rating_key):
    try:
        entry = _plex_entry(index)
        root = _plex_request(
            entry,
            "/library/metadata/%s/children" % quote(str(rating_key), safe="")
        )

        count = 0
        for episode in root.findall(".//Video"):
            if str(episode.attrib.get("type") or "") not in ("episode", ""):
                continue

            episode_key = str(episode.attrib.get("ratingKey") or "").strip()
            title = str(episode.attrib.get("title") or "Episode")
            ep = str(episode.attrib.get("index") or "").strip()
            season = str(episode.attrib.get("parentIndex") or "").strip()

            if season and ep:
                label = "S%sE%s · %s" % (season, ep, title)
            elif ep:
                label = "Episode %s · %s" % (ep, title)
            else:
                label = title

            if not episode_key:
                continue

            li = xbmcgui.ListItem(label=label)
            thumb = _plex_art_url(entry, episode.attrib.get("thumb") or "")
            if thumb:
                li.setArt({"icon": thumb, "thumb": thumb})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(
                HANDLE,
                plugin_url("plex_play", index=str(index), rating_key=episode_key),
                li,
                False
            )
            count += 1

        if count == 0:
            add_item("Keine Episoden gefunden")
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Plex",
            "Episoden konnten nicht geladen werden:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)


def plex_play(index, rating_key):
    try:
        entry = _plex_entry(index)
        root = _plex_request(
            entry,
            "/library/metadata/%s" % quote(str(rating_key), safe="")
        )

        part_key = ""
        for part in root.findall(".//Part"):
            candidate = str(part.attrib.get("key") or "").strip()
            if candidate:
                part_key = candidate
                break

        if not part_key:
            raise RuntimeError("Keine abspielbare Mediendatei gefunden.")

        stream_url = _plex_media_url(entry, part_key)
        li = xbmcgui.ListItem(path=stream_url)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 – Plex",
            "Wiedergabe nicht möglich:\n%s" % exc
        )
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def _mask_mac(value):
    value = str(value or "").strip()
    if not value:
        return "nicht gespeichert"
    parts = value.split(":")
    if len(parts) == 6 and all(parts):
        return ":".join(parts[:3] + ["XX", "XX", "XX"])
    if len(value) <= 6:
        return "vorhanden"
    return value[:4] + "..." + value[-2:]

def show_source_details(portal_type, index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get(portal_type, [])
    try:
        entry = entries[int(index)]
    except Exception:
        xbmcgui.Dialog().ok("TopCop1000", "Eintrag nicht gefunden.")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    name = str(entry.get("name") or "Quelle")
    lines = ["Name: %s" % name, "Typ: %s" % portal_type]
    if entry.get("url"):
        lines.append("Portal/URL: %s" % str(entry.get("url")))
    if portal_type == "stalker":
        mac = str(entry.get("mac") or "").strip()
        lines.append("MAC: %s" % _mask_mac(mac))
        lines.append("MAC gespeichert: %s" % ("JA" if mac else "NEIN"))
    elif portal_type in ("xtream", "enigma2"):
        lines.append("Benutzername: %s" % (str(entry.get("username")) if entry.get("username") else "nicht gespeichert"))
        lines.append("Passwort gespeichert: %s" % ("JA" if entry.get("password") else "NEIN"))
    elif portal_type == "plex":
        lines.append("Token gespeichert: %s" % ("JA" if entry.get("token") else "NEIN"))

    xbmcgui.Dialog().ok("TopCop1000 - Quelldaten", "\n".join(lines))
    xbmcplugin.endOfDirectory(HANDLE)

def source_open(portal_type, index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get(portal_type, [])
    try:
        entry = entries[int(index)]
    except Exception:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    name = entry.get("name") or "Quelle"
    add_item("Verbindung prüfen", "check_one", portal_type=portal_type, index=str(index))
    add_item("Quelle bearbeiten", "edit_source", portal_type=portal_type, index=str(index))
    add_item("Quelldaten anzeigen", "show_source_details", portal_type=portal_type, index=str(index))
    add_item("Wert kopieren", "copy_source", portal_type=portal_type, index=str(index))
    add_item("Quelle löschen", "delete_source", portal_type=portal_type, index=str(index))

    if portal_type == "m3u":
        source = entry.get("url") or entry.get("path") or ""
        if source:
            add_dir("Live TV", "m3u_custom", source=source, section="tv")
            add_dir("Filme", "m3u_custom", source=source, section="movies")
            add_dir("Serien", "m3u_custom", source=source, section="series")
    elif portal_type == "stalker":
        add_dir("Live TV", "stalker_live", index=str(index))
        add_item("Portal-Anmeldung testen", "stalker_test", index=str(index))
        add_item("Name: " + str(name))
        add_item("Typ: Stalker / Ministra")
    elif portal_type == "xtream":
        add_dir("Live TV", "xtream_categories", index=str(index), section="live")
        add_dir("Filme", "xtream_categories", index=str(index), section="vod")
        add_dir("Serien", "xtream_categories", index=str(index), section="series")
        add_item("Xtream-Anmeldung testen", "xtream_test", index=str(index))
        add_item("Name: " + str(name))
        add_item("Typ: Xtream Codes")
    elif portal_type == "enigma2":
        add_dir("Live TV", "enigma2_bouquets", index=str(index))
        add_item("Enigma2-Verbindung testen", "enigma2_test", index=str(index))
        add_item("Name: " + str(name))
        add_item("Typ: Enigma2")
    elif portal_type == "plex":
        add_dir("Filme", "plex_sections", index=str(index), kind="movie")
        add_dir("Serien", "plex_sections", index=str(index), kind="show")
        add_item("Plex-Verbindung testen", "plex_test", index=str(index))
        add_item("Name: " + str(name))
        add_item("Typ: Plex")
    else:
        add_item("Name: " + str(name))
        add_item("Typ: " + portal_type)
        add_item("Quelle gespeichert")
    xbmcplugin.endOfDirectory(HANDLE)



def _stalker_entry(index):
    cfg = load_settings()
    entries = cfg.get("sources", {}).get("stalker", [])
    try:
        return entries[int(index)]
    except Exception:
        raise StalkerError("Stalker-Eintrag nicht gefunden.")

def stalker_test(index):
    try:
        entry = _stalker_entry(index)
        profile, endpoint, token = stalker_get_profile(entry.get("url", ""), entry.get("mac", ""))
        login = profile.get("login") or profile.get("name") or profile.get("id") or "OK"
        xbmcgui.Dialog().ok("TopCop1000 – Stalker", "Anmeldung erfolgreich.\n\nPortal-API: %s\nProfil: %s" % (endpoint, login))
    except StalkerError as exc:
        xbmcgui.Dialog().ok("TopCop1000 – Stalker", "Anmeldung fehlgeschlagen:\n%s" % exc)
    except Exception as exc:
        xbmcgui.Dialog().ok("TopCop1000 – Stalker", "Fehler:\n%s" % exc)
    xbmcplugin.endOfDirectory(HANDLE)

def stalker_live(index):
    try:
        entry = _stalker_entry(index)
        genres = stalker_get_genres(entry.get("url", ""), entry.get("mac", ""))
        add_dir("Alle Sender", "stalker_genre", index=str(index), genre="__all__")
        count = 0
        for genre in genres:
            if not isinstance(genre, dict):
                continue
            gid = str(genre.get("id") or genre.get("genre_id") or "").strip()
            title = str(genre.get("title") or genre.get("name") or "").strip()
            if gid and title:
                add_dir(title, "stalker_genre", index=str(index), genre=gid)
                count += 1
        if count == 0:
            add_item("Keine Kategorien gemeldet – 'Alle Sender' verwenden")
    except StalkerError as exc:
        xbmcgui.Dialog().ok("TopCop1000 – Stalker", "Live-TV konnte nicht geladen werden:\n%s" % exc)
    except Exception as exc:
        xbmcgui.Dialog().ok("TopCop1000 – Stalker", "Fehler beim Laden:\n%s" % exc)
    xbmcplugin.endOfDirectory(HANDLE)

def stalker_genre(index, genre):
    try:
        entry = _stalker_entry(index)
        channels = stalker_get_channels(entry.get("url", ""), entry.get("mac", ""))
        shown = 0
        for channel in channels:
            if not isinstance(channel, dict):
                continue
            ch_genre = str(channel.get("tv_genre_id") or channel.get("genre_id") or channel.get("category_id") or "")
            if genre != "__all__" and ch_genre != str(genre):
                continue
            name = str(channel.get("name") or channel.get("title") or "Sender")
            cmd = channel.get("cmd") or channel.get("url") or ""
            if not cmd:
                continue
            icon = channel.get("logo") or channel.get("logo_url") or ""
            li = xbmcgui.ListItem(label=name)
            if icon:
                li.setArt({"icon": icon, "thumb": icon})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url("stalker_play", index=str(index), cmd=cmd), li, False)
            shown += 1
        if shown == 0:
            add_item("Keine Sender in dieser Kategorie gefunden")
    except StalkerError as exc:
        xbmcgui.Dialog().ok("TopCop1000 – Stalker", "Sender konnten nicht geladen werden:\n%s" % exc)
    except Exception as exc:
        xbmcgui.Dialog().ok("TopCop1000 – Stalker", "Fehler beim Laden der Sender:\n%s" % exc)
    xbmcplugin.endOfDirectory(HANDLE)

def stalker_play(index, cmd):
    try:
        entry = _stalker_entry(index)
        stream_url = stalker_create_link(entry.get("url", ""), entry.get("mac", ""), cmd)
        li = xbmcgui.ListItem(path=stream_url)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    except StalkerError as exc:
        xbmcgui.Dialog().ok("TopCop1000 – Stalker", "Wiedergabe nicht möglich:\n%s" % exc)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    except Exception as exc:
        xbmcgui.Dialog().ok("TopCop1000 – Stalker", "Wiedergabefehler:\n%s" % exc)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def saved_sources():
    cfg = load_settings()
    labels = {x["id"]: x["label"] for x in get_portal_types()}
    for typ, items in cfg.get("sources", {}).items():
        for i, entry in enumerate(items):
            name = entry.get("name") or f"Quelle {i+1}"
            add_dir(f"{labels.get(typ, typ)} → {name}", "source_open", portal_type=typ, index=str(i))
    xbmcplugin.endOfDirectory(HANDLE)

def show_m3u(section, source=None):
    cfg = load_settings()
    source = source or cfg.get("m3u_source", "")
    if not source:
        m3u_entries = cfg.get("sources", {}).get("m3u", [])
        if m3u_entries:
            first = m3u_entries[0]
            source = first.get("url") or first.get("path") or ""
    if not source:
        xbmcgui.Dialog().notification("TopCop1000", "Keine M3U-Quelle hinterlegt.", time=4000)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    try:
        entries = load_m3u(source)
        grouped = group_entries(entries)
        for e in grouped.get(section, []):
            add_stream(e.get("name", "Unbenannt"), e.get("url", ""), e.get("logo", ""))
    except Exception as exc:
        xbmcgui.Dialog().ok("TopCop1000", "M3U konnte nicht gelesen werden:\n%s" % exc)
    xbmcplugin.endOfDirectory(HANDLE)



def scan4all_archive():
    """Neutraler Archivbereich; scan4all wird nicht ausgeführt oder installiert."""
    files_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.topcop1000/scan4all/"
    )
    os.makedirs(files_dir, exist_ok=True)

    add_item("+ Archiv/Datei hinzufügen", "scan4all_add")
    names = [n for n in sorted(os.listdir(files_dir)) if os.path.isfile(os.path.join(files_dir, n))]
    if not names:
        add_item("Noch keine Datei hinterlegt")
    for name in names:
        add_item("" + name, "scan4all_info", file=name)
    xbmcplugin.endOfDirectory(HANDLE)

def scan4all_add():
    src = xbmcgui.Dialog().browseSingle(1, "scan4all-Datei auswählen", "files")
    if src:
        files_dir = xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.topcop1000/scan4all/"
        )
        os.makedirs(files_dir, exist_ok=True)
        dst = os.path.join(files_dir, os.path.basename(src))
        try:
            with xbmcvfs.File(src, "rb") as fsrc:
                data = fsrc.readBytes()
            with xbmcvfs.File(dst, "wb") as fdst:
                fdst.write(data)
            xbmcgui.Dialog().notification("TopCop1000", "Datei im scan4all-Archiv gespeichert.", time=3000)
        except Exception as exc:
            xbmcgui.Dialog().ok("TopCop1000", "Fehler beim Speichern:\n%s" % exc)
    xbmcplugin.endOfDirectory(HANDLE)

def scan4all_info(file):
    files_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.topcop1000/scan4all/"
    )
    path = os.path.join(files_dir, os.path.basename(file))
    xbmcgui.Dialog().ok(
        "TopCop1000 – scan4all",
        "Archivdatei:\n%s\n\nDieser Bereich speichert die Datei nur. TopCop1000 führt sie nicht aus und installiert sie nicht automatisch." % path
    )
    xbmcplugin.endOfDirectory(HANDLE)


def own_files():
    """Neutraler Dateibereich für eigene Dateien; keine automatische Ausführung/Installation."""
    files_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.topcop1000/files/"
    )
    os.makedirs(files_dir, exist_ok=True)

    add_item("+ Datei hinzufügen", "own_file_add")
    names = [n for n in sorted(os.listdir(files_dir)) if os.path.isfile(os.path.join(files_dir, n))]
    if not names:
        add_item("Noch keine eigenen Dateien gespeichert")
    for name in names:
        add_item("" + name, "own_file_info", file=name)
    xbmcplugin.endOfDirectory(HANDLE)

def own_file_add():
    src = xbmcgui.Dialog().browseSingle(1, "Datei auswählen", "files")
    if src:
        files_dir = xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.topcop1000/files/"
        )
        os.makedirs(files_dir, exist_ok=True)
        dst = os.path.join(files_dir, os.path.basename(src))
        try:
            with xbmcvfs.File(src, "rb") as fsrc:
                data = fsrc.readBytes()
            with xbmcvfs.File(dst, "wb") as fdst:
                fdst.write(data)
            xbmcgui.Dialog().notification("TopCop1000", "Datei gespeichert.", time=3000)
        except Exception as exc:
            xbmcgui.Dialog().ok("TopCop1000", "Fehler beim Speichern:\n%s" % exc)
    xbmcplugin.endOfDirectory(HANDLE)

def own_file_info(file):
    files_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.topcop1000/files/"
    )
    path = os.path.join(files_dir, os.path.basename(file))
    if os.path.exists(path):
        xbmcgui.Dialog().ok(
            "TopCop1000 – Eigene Dateien",
            "Gespeichert:\n%s\n\nDie Datei wird von TopCop1000 nicht automatisch ausgeführt oder installiert." % path
        )
    else:
        xbmcgui.Dialog().ok("TopCop1000", "Datei nicht gefunden.")
    xbmcplugin.endOfDirectory(HANDLE)



# ---------------------------------------------------------------------------
# ZIP-Manager
# ---------------------------------------------------------------------------

_ZIP_MAX_FILES = 20000
_ZIP_MAX_UNPACKED = 2 * 1024 * 1024 * 1024  # 2 GB Schutzgrenze


def _zip_local_path(path):
    """Kodi-Pfad möglichst in einen lokalen Dateisystempfad übersetzen."""
    path = str(path or "").strip()
    if not path:
        return ""
    translated = xbmcvfs.translatePath(path)
    return str(translated or path)


def _zip_size_text(value):
    try:
        value = float(value)
    except Exception:
        return "0 B"
    units = ["B", "kB", "MB", "GB"]
    pos = 0
    while value >= 1024.0 and pos < len(units) - 1:
        value /= 1024.0
        pos += 1
    if pos == 0:
        return "%d %s" % (int(value), units[pos])
    return "%.1f %s" % (value, units[pos])


def _zip_choose_folder(title, writable=False):
    browse_type = 3 if writable else 0
    selected = xbmcgui.Dialog().browseSingle(
        browse_type, title, "files"
    )
    selected = _zip_local_path(selected)
    if not selected:
        return ""
    if not os.path.isdir(selected):
        xbmcgui.Dialog().ok(
            "TopCop1000 ZIP-Manager",
            "Der ausgewählte Ordner ist für den ZIP-Manager nicht lokal erreichbar."
        )
        return ""
    return selected


def _zip_choose_file(title):
    selected = xbmcgui.Dialog().browseSingle(
        1, title, "files", ".zip"
    )
    selected = _zip_local_path(selected)
    if not selected:
        return ""
    if not os.path.isfile(selected):
        xbmcgui.Dialog().ok(
            "TopCop1000 ZIP-Manager",
            "Die ausgewählte ZIP-Datei ist nicht lokal erreichbar."
        )
        return ""
    return selected


def _zip_collect_files(folder, excluded_paths=None):
    folder = os.path.abspath(folder)
    excluded = set(os.path.abspath(x) for x in (excluded_paths or []))
    items = []
    for base, dirs, files in os.walk(folder):
        dirs[:] = [
            d for d in dirs
            if d != "__pycache__"
        ]
        for filename in files:
            if filename.endswith(".pyc"):
                continue
            full = os.path.abspath(os.path.join(base, filename))
            if full in excluded:
                continue
            items.append(full)
            if len(items) > _ZIP_MAX_FILES:
                raise RuntimeError(
                    "Der Ordner enthält mehr als %d Dateien." % _ZIP_MAX_FILES
                )
    return items


def _zip_pack_folder(folder, destination_zip):
    folder = os.path.abspath(folder)
    destination_zip = os.path.abspath(destination_zip)

    files = _zip_collect_files(folder, excluded_paths=[destination_zip])
    if not files:
        raise RuntimeError("Der ausgewählte Ordner enthält keine Dateien.")

    parent = os.path.dirname(folder.rstrip(os.sep))
    progress = xbmcgui.DialogProgress()
    progress.create("TopCop1000 ZIP-Manager", "Ordner wird gepackt …")

    try:
        with zipfile.ZipFile(
            destination_zip, "w", compression=zipfile.ZIP_DEFLATED
        ) as zf:
            total = len(files)
            for pos, full in enumerate(files, 1):
                if progress.iscanceled():
                    raise RuntimeError("Packen wurde abgebrochen.")
                arcname = os.path.relpath(full, parent).replace(os.sep, "/")
                zf.write(full, arcname=arcname)
                progress.update(
                    int(pos * 100 / max(total, 1)),
                    "%d von %d Dateien" % (pos, total)
                )
    except Exception:
        try:
            if os.path.isfile(destination_zip):
                os.remove(destination_zip)
        except Exception:
            pass
        raise
    finally:
        progress.close()

    return len(files), os.path.getsize(destination_zip)


def zip_pack():
    source = _zip_choose_folder("Ordner auswählen, der gepackt werden soll")
    if not source:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    destination = _zip_choose_folder(
        "Zielordner für die ZIP auswählen", writable=True
    )
    if not destination:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    base = os.path.basename(source.rstrip("/\\")) or "Archiv"
    default_name = "%s_%s.zip" % (
        base,
        time.strftime("%Y-%m-%d_%H-%M-%S")
    )
    name = xbmcgui.Dialog().input(
        "Name der ZIP-Datei",
        defaultt=default_name,
        type=xbmcgui.INPUT_ALPHANUM
    )
    name = str(name or "").strip()
    if not name:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    if not name.lower().endswith(".zip"):
        name += ".zip"
    name = os.path.basename(name)

    target = os.path.join(destination, name)
    if os.path.exists(target):
        if not xbmcgui.Dialog().yesno(
            "TopCop1000 ZIP-Manager",
            "Die Datei existiert bereits:\n\n%s\n\nÜberschreiben?" % name
        ):
            xbmcplugin.endOfDirectory(HANDLE)
            return

    try:
        count, size = _zip_pack_folder(source, target)
        xbmcgui.Dialog().ok(
            "TopCop1000 ZIP-Manager",
            "ZIP erfolgreich erstellt.\n\n"
            "Dateien: %d\n"
            "Größe: %s\n\n"
            "Gespeichert unter:\n%s"
            % (count, _zip_size_text(size), target)
        )
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 ZIP-Manager",
            "Packen fehlgeschlagen:\n%s" % exc
        )

    xbmcplugin.endOfDirectory(HANDLE)


def _zip_validate_members(zf):
    members = []
    total_size = 0
    for info in zf.infolist():
        name = str(info.filename or "").replace("\\", "/")
        if not name:
            continue

        # Keine absoluten oder rückwärts laufenden Pfade zulassen.
        if name.startswith("/") or re.match(r"^[A-Za-z]:/", name):
            raise RuntimeError("Unsicherer absoluter Pfad in der ZIP.")
        parts = [p for p in name.split("/") if p not in ("", ".")]
        if any(part == ".." for part in parts):
            raise RuntimeError("Unsicherer Pfad mit '..' in der ZIP.")

        # Symbolische Links nicht entpacken.
        unix_mode = (int(info.external_attr) >> 16) & 0xF000
        if unix_mode == 0xA000:
            raise RuntimeError("Symbolische Links werden nicht entpackt.")

        if not info.is_dir():
            total_size += int(info.file_size or 0)
            if total_size > _ZIP_MAX_UNPACKED:
                raise RuntimeError(
                    "Die entpackten Daten wären größer als 2 GB."
                )

        members.append((info, parts))
        if len(members) > _ZIP_MAX_FILES:
            raise RuntimeError(
                "Die ZIP enthält mehr als %d Einträge." % _ZIP_MAX_FILES
            )

    if not members:
        raise RuntimeError("Die ZIP ist leer.")

    return members, total_size


def _zip_collision_backup(destination, collisions):
    if not collisions:
        return ""

    backup_dir = os.path.join(destination, "ZIP-Manager-Sicherungen")
    os.makedirs(backup_dir, exist_ok=True)
    backup_path = os.path.join(
        backup_dir,
        "Vor_Entpacken_%s.zip" % time.strftime("%Y-%m-%d_%H-%M-%S")
    )

    with zipfile.ZipFile(
        backup_path, "w", compression=zipfile.ZIP_DEFLATED
    ) as zf:
        for full, rel in collisions:
            if os.path.isfile(full):
                zf.write(full, arcname=rel.replace(os.sep, "/"))

    return backup_path


def zip_unpack():
    archive = _zip_choose_file("ZIP-Datei zum Entpacken auswählen")
    if not archive:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    destination = _zip_choose_folder(
        "Zielordner zum Entpacken auswählen", writable=True
    )
    if not destination:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    progress = xbmcgui.DialogProgress()

    try:
        with zipfile.ZipFile(archive, "r") as zf:
            members, total_size = _zip_validate_members(zf)

            dest_real = os.path.realpath(destination)
            collisions = []

            for info, parts in members:
                if info.is_dir() or not parts:
                    continue
                rel = os.path.join(*parts)
                full = os.path.realpath(os.path.join(destination, rel))
                if full != dest_real and not full.startswith(dest_real + os.sep):
                    raise RuntimeError("Unsicherer Zielpfad erkannt.")
                if os.path.isfile(full):
                    collisions.append((full, rel))

            overwrite_mode = "overwrite"
            backup_path = ""

            if collisions:
                choice = xbmcgui.Dialog().select(
                    "%d vorhandene Datei(en) gefunden" % len(collisions),
                    [
                        "Vorhandene Dateien sichern und überschreiben",
                        "Vorhandene Dateien überspringen",
                        "Abbrechen",
                    ]
                )
                if choice < 0 or choice == 2:
                    xbmcplugin.endOfDirectory(HANDLE)
                    return
                if choice == 1:
                    overwrite_mode = "skip"
                else:
                    backup_path = _zip_collision_backup(
                        destination, collisions
                    )

            progress.create(
                "TopCop1000 ZIP-Manager",
                "ZIP wird entpackt …"
            )
            total = len(members)
            extracted = 0
            skipped = 0

            for pos, (info, parts) in enumerate(members, 1):
                if progress.iscanceled():
                    raise RuntimeError("Entpacken wurde abgebrochen.")

                if not parts:
                    continue
                rel = os.path.join(*parts)
                target = os.path.realpath(os.path.join(destination, rel))

                if target != dest_real and not target.startswith(dest_real + os.sep):
                    raise RuntimeError("Unsicherer Zielpfad erkannt.")

                if info.is_dir():
                    os.makedirs(target, exist_ok=True)
                else:
                    if os.path.exists(target) and overwrite_mode == "skip":
                        skipped += 1
                    else:
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        with zf.open(info, "r") as src, open(target, "wb") as dst:
                            shutil.copyfileobj(src, dst, length=1024 * 256)
                        extracted += 1

                progress.update(
                    int(pos * 100 / max(total, 1)),
                    "%d von %d Einträgen" % (pos, total)
                )

            progress.close()

            message = (
                "Entpacken abgeschlossen.\n\n"
                "Entpackte Dateien: %d\n"
                "Übersprungene Dateien: %d\n"
                "Gesamtgröße der ZIP-Inhalte: %s"
                % (extracted, skipped, _zip_size_text(total_size))
            )
            if backup_path:
                message += (
                    "\n\nVorhandene Dateien wurden vorher gesichert:\n%s"
                    % backup_path
                )

            xbmcgui.Dialog().ok(
                "TopCop1000 ZIP-Manager",
                message
            )

    except Exception as exc:
        try:
            progress.close()
        except Exception:
            pass
        xbmcgui.Dialog().ok(
            "TopCop1000 ZIP-Manager",
            "Entpacken fehlgeschlagen:\n%s" % exc
        )

    xbmcplugin.endOfDirectory(HANDLE)


def zip_show_contents():
    archive = _zip_choose_file("ZIP-Datei auswählen")
    if not archive:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    try:
        with zipfile.ZipFile(archive, "r") as zf:
            members, total_size = _zip_validate_members(zf)
            lines = [
                "Datei: %s" % os.path.basename(archive),
                "Einträge: %d" % len(members),
                "Entpackte Gesamtgröße: %s" % _zip_size_text(total_size),
                "",
            ]

            limit = 300
            for info, _ in members[:limit]:
                suffix = "/" if info.is_dir() else "  (%s)" % _zip_size_text(info.file_size)
                lines.append(str(info.filename) + suffix)

            if len(members) > limit:
                lines.append("")
                lines.append(
                    "... weitere %d Einträge werden nicht angezeigt."
                    % (len(members) - limit)
                )

            xbmcgui.Dialog().textviewer(
                "TopCop1000 ZIP-Inhalt",
                "\n".join(lines),
                usemono=True
            )

    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 ZIP-Manager",
            "ZIP konnte nicht gelesen werden:\n%s" % exc
        )

    xbmcplugin.endOfDirectory(HANDLE)


def zip_backup_topcop():
    source = _zip_local_path(
        "special://home/addons/plugin.video.topcop1000/"
    )
    if not os.path.isdir(source):
        xbmcgui.Dialog().ok(
            "TopCop1000 ZIP-Manager",
            "Der TopCop1000-Plugin-Ordner wurde nicht gefunden."
        )
        xbmcplugin.endOfDirectory(HANDLE)
        return

    destination = _zip_choose_folder(
        "Zielordner für TopCop1000-Sicherung auswählen", writable=True
    )
    if not destination:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    target = os.path.join(
        destination,
        "TopCop1000_PLUGIN_%s.zip"
        % time.strftime("%Y-%m-%d_%H-%M-%S")
    )

    try:
        count, size = _zip_pack_folder(source, target)
        xbmcgui.Dialog().ok(
            "TopCop1000 ZIP-Manager",
            "TopCop1000 wurde vollständig als ZIP gesichert.\n\n"
            "Dateien: %d\n"
            "Größe: %s\n\n"
            "%s"
            % (count, _zip_size_text(size), target)
        )
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 ZIP-Manager",
            "TopCop1000-Sicherung fehlgeschlagen:\n%s" % exc
        )

    xbmcplugin.endOfDirectory(HANDLE)


def zip_manager():
    add_item("Ordner als ZIP packen", "zip_pack")
    add_item("ZIP entpacken", "zip_unpack")
    add_item("ZIP-Inhalt anzeigen", "zip_show_contents")
    add_item("TopCop1000-Plugin komplett als ZIP sichern", "zip_backup_topcop")
    add_item("Hinweis: Kodi-Add-ons weiterhin über 'Aus ZIP-Datei installieren'")
    xbmcplugin.endOfDirectory(HANDLE)



def permanent_installer():
    """Startet den fest mit TopCop1000 ausgelieferten Installer/Updater."""
    path = xbmcvfs.translatePath(
        "special://home/addons/plugin.video.topcop1000/resources/tools/TopCop1000_Installer.py"
    )
    try:
        if not os.path.isfile(path):
            raise RuntimeError("Installer-Datei wurde nicht gefunden.")
        spec = importlib.util.spec_from_file_location("topcop_permanent_installer", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        if not hasattr(mod, "main"):
            raise RuntimeError("Installer besitzt keine main()-Funktion.")
        mod.main({"source": "TopCop1000"})
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "TopCop1000 Installer",
            "Installer konnte nicht gestartet werden:\n%s" % exc
        )
    xbmcplugin.endOfDirectory(HANDLE)


def _python_modules_dir():
    path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.topcop1000/modules/")
    os.makedirs(path, exist_ok=True)
    return path


def _python_copy_to_local(src, suffix=".py"):
    temp_root = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.topcop1000/python_installer_tmp/")
    os.makedirs(temp_root, exist_ok=True)
    fd, path = tempfile.mkstemp(prefix="topcop_", suffix=suffix, dir=temp_root)
    os.close(fd)
    try:
        with xbmcvfs.File(src, "rb") as fsrc:
            data = fsrc.readBytes()
        with open(path, "wb") as fdst:
            fdst.write(data)
        return path
    except Exception:
        try:
            os.remove(path)
        except Exception:
            pass
        raise


def _python_manual_install_dialog():
    dlg = xbmcgui.Dialog()
    if not dlg.yesno(
        "TopCop1000 - Manuelle Modulinstallation",
        "Nur reine Python-Pakete (Universal-Wheels) werden akzeptiert.\n\n"
        "Binärpakete, EXE/DLL/SO-Dateien und Quellcode-Builds werden automatisch abgelehnt.\n\n"
        "Paketname jetzt selbst eingeben?"
    ):
        return False
    project = (dlg.input(
        "PyPI-Paketname eingeben",
        type=xbmcgui.INPUT_ALPHANUM
    ) or "").strip()
    if not project:
        return False
    ok, message = manual_install(project)
    dlg.ok(
        "TopCop1000 - Modulinstallation",
        ("Erfolgreich.\n\n" if ok else "Nicht installiert.\n\n") + message
    )
    return ok


def _python_dependency_gate(analyze_again, label, action_word="hinzufügen", confirm_when_ok=True):
    dlg = xbmcgui.Dialog()
    while True:
        report = analyze_again()
        if report_ok(report):
            if not confirm_when_ok:
                return True
            return dlg.yesno(
                "TopCop1000 - Abhängigkeitsprüfung",
                format_report(report, label) +
                "\n\nPrüfung OK. Jetzt %s?" % action_word
            )

        choices = [
            "Abbrechen",
            "Details anzeigen",
            "Fehlende Module installieren",
            "Paketname manuell installieren",
            "Trotzdem %s - auf eigenes Risiko" % action_word,
        ]
        pos = dlg.select(
            "TopCop1000 - Fehlende Abhängigkeiten",
            choices
        )
        if pos < 0 or pos == 0:
            return False
        if pos == 1:
            try:
                dlg.textviewer(
                    "TopCop1000 - Abhängigkeitsdetails",
                    format_report(report, label)
                )
            except Exception:
                dlg.ok("TopCop1000 - Abhängigkeitsdetails", format_report(report, label))
            continue
        if pos == 2:
            results = install_missing_modules(report)
            if not results:
                dlg.ok(
                    "TopCop1000 - Modulinstallation",
                    "Für die fehlenden Module ist keine sichere automatische Installation freigegeben.\n\n"
                    "Du kannst einen PyPI-Paketnamen manuell eingeben oder die Datei auf eigenes Risiko fortsetzen."
                )
                continue
            lines = []
            for name, ok, message in results:
                lines.append(("OK: " if ok else "FEHLER: ") + message)
            dlg.ok("TopCop1000 - Modulinstallation", "\n".join(lines))
            continue
        if pos == 3:
            _python_manual_install_dialog()
            continue
        if pos == 4:
            warning = (
                "Dieses Paket enthält fehlende oder nicht vollständig prüfbare Abhängigkeiten. "
                "Die Installation kann fehlschlagen oder das Paket kann anschließend nicht funktionieren.\n\n"
                "Fortfahren erfolgt auf eigenes Risiko.\n\n"
                "Trotzdem %s?" % action_word
            )
            return dlg.yesno("TopCop1000 - WARNUNG", warning)


def _python_backup_existing(path, backup_root):
    if not os.path.exists(path):
        return
    os.makedirs(backup_root, exist_ok=True)
    target = os.path.join(backup_root, os.path.basename(path))
    if os.path.isdir(path):
        if os.path.exists(target):
            shutil.rmtree(target, ignore_errors=True)
        shutil.copytree(path, target)
    else:
        shutil.copy2(path, target)


def python_center():
    add_item("+ PY hinzufügen", "python_add")
    add_item("+ PY-Paket aus ZIP installieren", "python_zip_add")
    add_item("Modul/Paket manuell installieren", "python_manual_package")
    add_item("Installationsprotokoll", "python_install_log")
    add_dir("PY-Ausgaben", "outputs")
    modules_dir = _python_modules_dir()
    for fn in sorted(os.listdir(modules_dir)):
        if fn.endswith(".py"):
            add_item("" + fn[:-3], "python_run", file=fn)
    xbmcplugin.endOfDirectory(HANDLE)


def python_add():
    src = xbmcgui.Dialog().browseSingle(1, "PY-Datei auswählen", "files", ".py")
    if not src:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    modules_dir = _python_modules_dir()
    local_temp = None
    try:
        local_temp = _python_copy_to_local(src, ".py")
        label = os.path.basename(src) or os.path.basename(local_temp)
        analyze_again = lambda: analyze_python_file(local_temp)
        if not _python_dependency_gate(analyze_again, label, "hinzufügen", True):
            xbmcplugin.endOfDirectory(HANDLE)
            return

        dst = os.path.join(modules_dir, os.path.basename(src))
        if os.path.exists(dst):
            if not xbmcgui.Dialog().yesno(
                "TopCop1000",
                "Eine PY-Datei mit diesem Namen existiert bereits.\n\nVorhandene Datei sichern und ersetzen?"
            ):
                xbmcplugin.endOfDirectory(HANDLE)
                return
            backup_root = os.path.join(
                xbmcvfs.translatePath("special://profile/addon_data/plugin.video.topcop1000/python_backups/"),
                time.strftime("%Y-%m-%d_%H-%M-%S")
            )
            _python_backup_existing(dst, backup_root)
        shutil.copy2(local_temp, dst)
        xbmcgui.Dialog().notification("TopCop1000", "PY geprüft und hinzugefügt.", time=3000)
    except Exception as exc:
        xbmcgui.Dialog().ok("TopCop1000", "Fehler beim PY-Import:\n%s" % exc)
    finally:
        if local_temp:
            try:
                os.remove(local_temp)
            except Exception:
                pass
    xbmcplugin.endOfDirectory(HANDLE)


def python_zip_add():
    src = xbmcgui.Dialog().browseSingle(1, "PY-Paket-ZIP auswählen", "files", ".zip")
    if not src:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    local_zip = None
    local_zip_is_temp = False
    prepared = None
    try:
        local_path = xbmcvfs.translatePath(src)
        if os.path.isfile(local_path):
            local_zip = local_path
        else:
            local_zip = _python_copy_to_local(src, ".zip")
            local_zip_is_temp = True

        work_parent = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.topcop1000/python_installer_tmp/")
        os.makedirs(work_parent, exist_ok=True)
        prepared = prepare_python_zip(local_zip, work_parent)
        label = os.path.basename(src) or prepared["name"]
        analyze_again = lambda: analyze_python_tree(prepared["work"])
        if not _python_dependency_gate(analyze_again, label, "installieren", True):
            xbmcplugin.endOfDirectory(HANDLE)
            return

        packages_root = script_packages_dir()
        os.makedirs(packages_root, exist_ok=True)
        destination = os.path.join(packages_root, prepared["name"])
        modules_dir = _python_modules_dir()
        wrapper = os.path.join(modules_dir, prepared["name"] + ".py")
        metadata = wrapper + ".topcop.json"

        if os.path.exists(destination) or os.path.exists(wrapper):
            if not xbmcgui.Dialog().yesno(
                "TopCop1000 - PY-Paket",
                "Ein PY-Paket mit diesem Namen existiert bereits.\n\nSichern und ersetzen?"
            ):
                xbmcplugin.endOfDirectory(HANDLE)
                return
            backup_root = os.path.join(
                xbmcvfs.translatePath("special://profile/addon_data/plugin.video.topcop1000/python_backups/"),
                time.strftime("%Y-%m-%d_%H-%M-%S") + "_" + prepared["name"]
            )
            _python_backup_existing(destination, backup_root)
            _python_backup_existing(wrapper, backup_root)
            _python_backup_existing(metadata, backup_root)

        if os.path.isdir(destination):
            shutil.rmtree(destination, ignore_errors=True)
        shutil.copytree(prepared["work"], destination)

        module_name = "topcop_zip_" + re.sub(r"\W+", "_", prepared["name"])
        wrapper_lines = [
            "# -*- coding: utf-8 -*-",
            "# Automatisch von TopCop1000 erzeugter PY-Paket-Starter.",
            "import importlib.util",
            "import os",
            "import sys",
            "import xbmcvfs",
            "",
            "def main(context=None):",
            "    root = xbmcvfs.translatePath(%r)" % (
                "special://profile/addon_data/plugin.video.topcop1000/python_script_packages/%s/" % prepared["name"]
            ),
            "    entry = os.path.join(root, *%r.split('/'))" % prepared["entry"],
            "    if root not in sys.path:",
            "        sys.path.insert(0, root)",
            "    spec = importlib.util.spec_from_file_location(%r, entry)" % module_name,
            "    if spec is None or spec.loader is None:",
            "        raise RuntimeError('PY-Paket konnte nicht geladen werden.')",
            "    mod = importlib.util.module_from_spec(spec)",
            "    spec.loader.exec_module(mod)",
            "    if not hasattr(mod, 'main'):",
            "        raise RuntimeError('Die Startdatei des PY-Pakets benötigt main(context).')",
            "    return mod.main(context or {})",
            "",
        ]
        with open(wrapper, "w", encoding="utf-8") as fh:
            fh.write("\n".join(wrapper_lines))
        with open(metadata, "w", encoding="utf-8") as fh:
            json.dump({"package": prepared["name"], "entry": prepared["entry"]}, fh, ensure_ascii=False, indent=2)

        xbmcgui.Dialog().ok(
            "TopCop1000 - PY-Paket",
            "PY-Paket erfolgreich geprüft und installiert.\n\n"
            "Name: %s\nStartdatei: %s" % (prepared["name"], prepared["entry"])
        )
    except Exception as exc:
        xbmcgui.Dialog().ok("TopCop1000 - PY-Paket", "Installation fehlgeschlagen:\n%s" % exc)
    finally:
        if prepared and prepared.get("work"):
            shutil.rmtree(prepared["work"], ignore_errors=True)
        if local_zip_is_temp and local_zip:
            try:
                os.remove(local_zip)
            except Exception:
                pass
    xbmcplugin.endOfDirectory(HANDLE)


def python_manual_package_install():
    _python_manual_install_dialog()
    xbmcplugin.endOfDirectory(HANDLE)


def python_install_log():
    text = read_log(100)
    try:
        xbmcgui.Dialog().textviewer("TopCop1000 - Installationsprotokoll", text)
    except Exception:
        xbmcgui.Dialog().ok("TopCop1000 - Installationsprotokoll", text[-3500:])
    xbmcplugin.endOfDirectory(HANDLE)


def _python_analysis_for_installed(file, path):
    meta_path = path + ".topcop.json"
    if os.path.isfile(meta_path):
        try:
            with open(meta_path, "r", encoding="utf-8") as fh:
                meta = json.load(fh)
            package = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(meta.get("package") or ""))
            root = os.path.join(script_packages_dir(), package)
            if os.path.isdir(root):
                return lambda: analyze_python_tree(root), root
        except Exception:
            pass
    return lambda: analyze_python_file(path), path


def python_run(file):
    modules_dir = _python_modules_dir()
    path = os.path.join(modules_dir, file)
    safe_name = os.path.splitext(os.path.basename(file))[0]
    outdir = os.path.join(output_root(), safe_name)
    os.makedirs(outdir, exist_ok=True)
    try:
        analyze_again, _ = _python_analysis_for_installed(file, path)
        report = analyze_again()
        if not report_ok(report):
            if not _python_dependency_gate(analyze_again, safe_name, "ausführen", False):
                xbmcplugin.endOfDirectory(HANDLE)
                return

        ensure_package_path()
        spec = importlib.util.spec_from_file_location(
            "topcop_user_module_" + re.sub(r"\W+", "_", safe_name), path
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        if hasattr(mod, "main"):
            result = mod.main({"output_dir": outdir})
            if result is not None:
                xbmcgui.Dialog().ok("TopCop1000", str(result))
        else:
            xbmcgui.Dialog().ok("TopCop1000", "Die PY benötigt main(context).")
    except Exception as exc:
        xbmcgui.Dialog().ok("TopCop1000", "PY-Fehler:\n%s" % exc)
    xbmcplugin.endOfDirectory(HANDLE)

def outputs():
    data = list_outputs()
    if not data:
        add_item("Noch keine Ausgaben vorhanden")
    for group in data:
        add_dir("" + group, "output_group", group=group)
    xbmcplugin.endOfDirectory(HANDLE)

def output_group(group):
    for item in list_outputs().get(group, []):
        add_item("" + item["name"])
    xbmcplugin.endOfDirectory(HANDLE)

def run():
    p = params()
    action = p.get("action")
    if not action:
        root()
    elif action == "portal_center":
        portal_center()
    elif action == "phone_paste_info":
        phone_paste_info()
    elif action == "portal_type":
        portal_type(p.get("portal_type", "m3u"))
    elif action == "add_source":
        add_source(p.get("portal_type", "m3u"))
    elif action == "saved_sources":
        saved_sources()
    elif action == "source_open":
        source_open(p.get("portal_type", "m3u"), p.get("index", "0"))
    elif action == "show_source_details":
        show_source_details(p.get("portal_type", "m3u"), p.get("index", "0"))
    elif action == "edit_source":
        edit_source(p.get("portal_type", "m3u"), p.get("index", "0"))
    elif action == "copy_source":
        copy_source(p.get("portal_type", "m3u"), p.get("index", "0"))
    elif action == "delete_source":
        delete_source(p.get("portal_type", "m3u"), p.get("index", "0"))
    elif action == "portal_overview":
        portal_overview()
    elif action == "check_one":
        check_one(p.get("portal_type", "m3u"), p.get("index", "0"))
    elif action == "check_all":
        check_all()
    elif action == "m3u_section":
        show_m3u(p.get("section", "tv"))
    elif action == "m3u_custom":
        show_m3u(p.get("section", "tv"), p.get("source"))
    elif action == "stalker_test":
        stalker_test(p.get("index", "0"))
    elif action == "stalker_live":
        stalker_live(p.get("index", "0"))
    elif action == "stalker_genre":
        stalker_genre(p.get("index", "0"), p.get("genre", "__all__"))
    elif action == "stalker_play":
        stalker_play(p.get("index", "0"), p.get("cmd", ""))
    elif action == "xtream_test":
        xtream_test(p.get("index", "0"))
    elif action == "xtream_categories":
        xtream_categories(
            p.get("index", "0"),
            p.get("section", "live")
        )
    elif action == "xtream_items":
        xtream_items(
            p.get("index", "0"),
            p.get("section", "live"),
            p.get("category", "__all__")
        )
    elif action == "xtream_series_info":
        xtream_series_info(
            p.get("index", "0"),
            p.get("series_id", "")
        )
    elif action == "enigma2_test":
        enigma2_test(p.get("index", "0"))
    elif action == "enigma2_bouquets":
        enigma2_bouquets(p.get("index", "0"))
    elif action == "enigma2_services":
        enigma2_services(
            p.get("index", "0"),
            p.get("sref", "")
        )
    elif action == "plex_test":
        plex_test(p.get("index", "0"))
    elif action == "plex_sections":
        plex_sections(
            p.get("index", "0"),
            p.get("kind", "movie")
        )
    elif action == "plex_section_items":
        plex_section_items(
            p.get("index", "0"),
            p.get("section_key", ""),
            p.get("kind", "movie")
        )
    elif action == "plex_show_seasons":
        plex_show_seasons(
            p.get("index", "0"),
            p.get("rating_key", "")
        )
    elif action == "plex_season_episodes":
        plex_season_episodes(
            p.get("index", "0"),
            p.get("rating_key", "")
        )
    elif action == "plex_play":
        plex_play(
            p.get("index", "0"),
            p.get("rating_key", "")
        )
    elif action == "zip_manager":
        zip_manager()
    elif action == "zip_pack":
        zip_pack()
    elif action == "zip_unpack":
        zip_unpack()
    elif action == "zip_show_contents":
        zip_show_contents()
    elif action == "zip_backup_topcop":
        zip_backup_topcop()
    elif action == "permanent_installer":
        permanent_installer()
    elif action == "python_center":
        python_center()
    elif action == "own_files":
        own_files()
    elif action == "scan4all_archive":
        scan4all_archive()
    elif action == "scan4all_add":
        scan4all_add()
    elif action == "scan4all_info":
        scan4all_info(p.get("file", ""))
    elif action == "own_file_add":
        own_file_add()
    elif action == "own_file_info":
        own_file_info(p.get("file", ""))
    elif action == "python_add":
        python_add()
    elif action == "python_zip_add":
        python_zip_add()
    elif action == "python_manual_package":
        python_manual_package_install()
    elif action == "python_install_log":
        python_install_log()
    elif action == "python_run":
        python_run(p.get("file", ""))
    elif action == "outputs":
        outputs()
    elif action == "output_group":
        output_group(p.get("group", ""))
    else:
        root()

if __name__ == "__main__":
    run()
